from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))           
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"""The code below will display "Unrecognized name" when the user types "tim". How would you fix it?
                 
    {VA}name{C} = {FU}input{C}{GO}({C}{ST}"What is your name? "{C}{GO}){C}
    {M}if{C} {VA}name{C} == {ST}"tim"{C}:
        {FU}print{C}{GO}({C}{ST}"Short for Timothy."{C}{GO}){C}
    {M}if{C} {VA}name{C} == {ST}"jim"{C}:
        {FU}print{C}{GO}({C}{ST}"Short for James."{C}{GO}){C}
    {M}else{C}:
        {FU}print{C}{GO}({C}{ST}"Unrecognized name."{C}{GO}){C}    
        \n(a) Change the {M}else{C} to {M}if{C} {VA}name{C} != {ST}"jim"{C}.\n(b) Change the {M}else{C} to {M}if{C} {VA}name{C} != {ST}"tim"{C}.\n(c) Change the first {M}if{C} to {M}elif{C}.\n(d) Change the second {M}if{C} to {M}elif{C}.\n\n""", "d"),
        Question(f"Which of the following is a valid python if else decision tree?\n\n(a) if-elif-elif-else\n(b) elif-else-if\n(c) if-then-fi\n(d) None of the above\n\n", "a"),
        Question(f"What is one reason if-elif-else can be better than separate if-else decisions?\n\n(a) It's not. if-else is better.\n(b) if-elif-else is shorter to write.\n(c) if-elif-else often runs faster because it skips further checks after finding a match.\n(d) if-elif-else is easier to say.\n\n", "c"),
        Question(f"""What is the name for this structure?
                 
    {M}if{C} {VA}a{C} == [#B5CEA8]5{C}:
        {M}if{C} {VA}b{C} == [#B5CEA8]3{C}:
            {FU}print{C}{GO}({C}{ST}"Hello"{C}{GO}){C}               
        \n(a) Stacked if\n(b) Nested if\n(c) Multi-layer if\n(d) Iffy if\n\n""", "b"),
        Question(f"""What is wrong with this code?
                   
    {VA}animal{C} = {FU}input{C}{GO}({C}{ST}"Do you like Zebras?"{C}{GO}){C}
    {M}if{C} {ST}"yes"{C}:
        {FU}print{C}{GO}({C}[blue]f{C}{ST}"I do too! They have pretty stripes."{C}{GO}){C}
        \n(a) It is a string, so it only works if {VA}animal{C} is {ST}"grasshopper"{C}.\n(b) The input should have [green]int{C}{GO}(){C} before it.\n(c) {M}if{C} {ST}"yes"{C}: is the same as saying {M}if{C} {ST}"yes"{C} != {ST}""{C}:, so the print statement will always run.\n(d) There is nothing wrong with it.\n\n""", "c"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()