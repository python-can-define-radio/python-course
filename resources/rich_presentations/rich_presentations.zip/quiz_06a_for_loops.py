from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        Incorrect:      ❌  {question}

        Correct:        ✅  {item.answer}


        Hit enter for next question.
        """, style="red")
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))              
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"""What is the value of {VA}var{C} after the for loop runs?

    {VA}var{C} = {NU}10{C}
    {M}for{C} {VA}i{C} {M}in{C} {GR}range{C}{GO}({C}{NU}10{C}{GO}){C}:
        {VA}var{C} += {NU}1{C}
    {FU}print{C}{GO}({C}{VA}var{C}{GO}){C}
        \n(a) {NU}10{C}\n(b) {NU}40{C}\n(c) {NU}20{C}\n(d) {NU}11{C}\n\n""", "c"),
        Question(f"""What is the output of the following for loop?
                 
    {M}for{C} {VA}num{C} {M}in{C} {GR}range{C}{GO}({C}{NU}2{C}, {NU}-5{C}, {NU}-1{C}{GO}){C}:
        {FU}print{C}{GO}({C}{VA}num{C}, {VA}end{C}={ST}", "{C}{GO}){C}                         
        \n(a) {NU}-4, -3, -2, -1, 0, 1, 2,{C} \n(b) {NU}2, 3, 4,{C} \n(c) {NU}2, 1, 0, -1, -2, -3, -4, {C}\n(d) {NU}2, 1, 0, -1, -2, -3, -4, -5, {C}\n\n""", "c"),
        Question(f"What is the purpose of a for loop in Python?\n\n(a) To define a function.\n(b) To iterate over a sequence or iterable.\n(c) To create a conditional statement.\n(d) To perform arithmetic operations.\n\n", "b"),
        Question(f"In a for loop, how can you access both the index and the value of each element in a list?\n\n(a) Using the index method.\n(b) Using the enumerate function.\n(c) Using the iter function.\n(d) Using a while loop.\n\n", "b"),
        Question(f"""What will this print?
                 
    {VA}fruits{C} = {GO}[{C}{ST}"apple"{C}, {ST}"banana"{C}, {ST}"cherry"{C}{GO}]{C}
    {M}for{C} {VA}x{C} {M}in{C} {VA}fruits{C}:
        {FU}print{C}{GO}({C}{VA}x{C}{GO}){C}
        {M}if{C} {VA}x{C} == {ST}"banana"{C}:
            {M}break{C}                          
        \n(a) apple, banana\n(b) apple, banana, cherry\n(c) banana\n(d) banana, cherry\n\n""", "a"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()