## What is a class? 

## A class is a code template for creating objects. Objects have member variables and have behaviour associated with them. In python a class is created by the keyword class.
