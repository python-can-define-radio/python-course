from prompt_toolkit.shortcuts import radiolist_dialog
import os

dir_root = "~/Desktop/rich_presentations/"

def act_on_choice(choice: str):
    if choice == "lec_01a_01b_prints_inputs_variables.py":
       os.system(f"python3 {dir_root}{choice}")

    elif choice == "lec_02a_02b_number_systems_operators.py":
       os.system(f"python3 {dir_root}{choice}")

    elif choice == "lec_03a_if_else.py":
       os.system(f"python3 {dir_root}{choice}")
        
    elif choice == "lec_03b_if_else_common_mistakes.py":
       os.system(f"python3 {dir_root}{choice}")

    elif choice == "lec_04a_lists.py":
       os.system(f"python3 {dir_root}{choice}")
        
    elif choice == "lec_04b_random.py":
       os.system(f"python3 {dir_root}{choice}")
        
    elif choice == "lec_05a_file_writing.py":
       os.system(f"python3 {dir_root}{choice}")

    elif choice == "lec_06a_for_loops.py":
       os.system(f"python3 {dir_root}{choice}")
        
    elif choice == "lec_06b_while_loops.py":
       os.system(f"python3 {dir_root}{choice}")
        
    elif choice == "lec_07a_dictionaries.py":
       os.system(f"python3 {dir_root}{choice}")

    elif choice == "lec_08a_b_functions.py":
       os.system(f"python3 {dir_root}{choice}")   
 
    else:
        print("Invalid choice:", choice)

def get_user_choice() -> str:
    return radiolist_dialog(
            title='Main Menu',
            text=f'Choose a Rich Presentation to launch.',
            values=[
                ("lec_01a_01b_prints_inputs_variables.py", "Prints and Inputs"),
                ("lec_02a_02b_number_systems_operators", "Number Systems"),
                ("lec_03a_if_else", "IF-Else"),
                ("lec_03b_if_else_common_mistakes", "IF-Else common mistakes"),
                ("lec_04a_lists", "Lists"),
                ("lec_04b_random", "Random module"),
                ("lec_05a_file_writing", "File writing"),
                ("lec_06a_for_loops", "For loops"),
                ("lec_06b_while_loops", "While loops"),
                ("lec_07a_dictionaries", "Dictionaries"),
                ("lec_08a_b_functions", "Functions"),
            ],
        ).run()
    

choice = get_user_choice()
act_on_choice(choice)