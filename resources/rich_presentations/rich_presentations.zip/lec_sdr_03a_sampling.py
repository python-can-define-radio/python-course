from rich.console import Console
from rich.markdown import Markdown
from guizero import App, Picture, Text
import tkinter as tk
from rich_presentation_helpers import pip_install_for_presentation, auto_resize



pip_install_for_presentation()
auto_resize()


console = Console()
print = console.print
input = console.input
THEME = "zenburn"
APP = App(title="Prints and Inputs", width=600, height=400)

IMAGE_DATA = ""

image = tk.PhotoImage(data=IMAGE_DATA)
picture = Picture(APP, image=image)
message = Text(APP, text="Close Window to go to the first example.")
APP.display()


def md(*args, **kwargs):
    return Markdown(*args, code_theme=THEME, inline_code_theme=THEME, inline_code_lexer="python3", **kwargs)


def printwait(*args, **kwargs):
    print(*args, **kwargs)
    input()

console.clear()
##########################################
printwait(md(f"""
# Functions 

ℹ️  Lets start with a basic function.
              
```python3
def greeting():
  print("Welcome to python class.")

## This runs or "calls" the function.
greeting()
```

"""))            

printwait(md(f"""
```python3
Welcome to python class.
```
             
A function is a block of code which only runs when it is called.

"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  We can add required parameters to a function.
              
```python3
## myname is the parameter. 
def greetingwithname(myname):
  print("Welcome to python class " + myname + ".")

## Now we have to add an argument when we call the function.
greetingwithname("Jonathan")
greetingwithname("Harry")
greetingwithname("Linda")
```

"""))            

printwait(md(f"""
```python3
Welcome to python class Jonathan.  
Welcome to python class Harry.  
Welcome to python class Linda.
```
             
The argument is passed to the functions parameter which is then used.

"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  Taken a step further we can pass a variable in as the argument.
              
```python3
def greetingwithname(myname):
  print("Welcome to python class " + myname + ".")

user1 = input("What is your first name? ")

greetingwithname(user1)
```

"""))            

def greetingwithname(myname):
  print("Welcome to python class " + myname + ".")

user1 = input("What is your first name? ")

greetingwithname(user1)

input()

printwait(md(f"""
             
Now the variable is passed in as the argument to the functions parameter which is then used.

"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  Functions can also be used as a way to minimize repetitive code.  
    In this example we will use the turtle module and draw some triangles.
              
```python3
import turtle

turtle.forward(100)
turtle.left(120)
turtle.forward(100)
turtle.left(120)
turtle.forward(100)
turtle.left(120)

turtle.forward(200)
turtle.left(120)
turtle.forward(200)
turtle.left(120)
turtle.forward(200)
turtle.left(120)

turtle.forward(300)
turtle.left(120)
turtle.forward(300)
turtle.left(120)
turtle.forward(300)
turtle.left(120)

turtle.mainloop()
```

"""))            

import turtle
from turtle import Screen


WIDTH, HEIGHT = 720, 720

screen = Screen()
screen.setup(WIDTH + 4, HEIGHT + 8)  # fudge factors due to window borders & title bar
screen.setworldcoordinates(0, 0, WIDTH, HEIGHT)

turtle.forward(100)
turtle.left(120)
turtle.forward(100)
turtle.left(120)
turtle.forward(100)
turtle.left(120)

turtle.forward(200)
turtle.left(120)
turtle.forward(200)
turtle.left(120)
turtle.forward(200)
turtle.left(120)

turtle.forward(300)
turtle.left(120)
turtle.forward(300)
turtle.left(120)
turtle.forward(300)
turtle.left(120)

turtle.penup()
turtle.goto(250, 250)
turtle.pendown()
input()
console.clear()
##########################################
printwait(md(f"""

ℹ️  This function will do the exact same thing with about half the code.  
    I moved the pen to show them both on the same screen.
              
```python3
import turtle

def drawTriangle(forward, left):
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)

drawTriangle(100, 120)
drawTriangle(200, 120)
drawTriangle(300, 120)

turtle.mainloop()
```

""")) 

def drawTriangle(forward, left):
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)

drawTriangle(100, 120)
drawTriangle(200, 120)
drawTriangle(300, 120)
turtle.penup()
turtle.goto(360,360)
turtle.pendown()
input()
console.clear()
##########################################
printwait(md(f"""

ℹ️  Repeat function using another function with color added to make it interesting.
              
```python3
import turtle

def drawTriangle(forward, color, left=120):
    turtle.begin_fill()
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.fillcolor(color) 
    turtle.end_fill()  

def repeattripletriangle(right):
    turtle.right(right)
    drawTriangle(300, "orange")
    drawTriangle(200, "blue")
    drawTriangle(100, "green")
    
turtle.speed(20)
turtle.shape("turtle")
turtle.hideturtle()

## instead of calling the function 6 times to complete a 360 circle.
for value in range(0, 6):
    repeattripletriangle(60)

turtle.mainloop()
```

""")) 

turtle.clear()

def drawTriangle(forward, color, left=120):
    turtle.begin_fill()
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.forward(forward)
    turtle.left(left)
    turtle.fillcolor(color) 
    turtle.end_fill()  


def repeattripletriangle(right):
    turtle.right(right)
    drawTriangle(300, "orange")
    drawTriangle(200, "blue")
    drawTriangle(100, "green")
    

turtle.speed(20)
turtle.shape("turtle")
turtle.hideturtle()

## instead of calling the function 6 times to complete a 360 circle.
for value in range(0, 6):
    repeattripletriangle(60)
turtle.penup()
turtle.goto(125, 650)
turtle.pendown()
turtle.write("Text added just because I can", font=("Arial", 26, "bold"))
turtle.mainloop()
input()

console.clear()
##########################################
from asciimatics.screen import Screen
from asciimatics.scene import Scene
from asciimatics.effects import Cycle, Stars
from asciimatics.renderers import FigletText
 

def done(screen):
    effects = [
        Cycle(
            screen,
            FigletText("Python", font='ogre'),
            screen.height // 2 - 10),
        Cycle(
            screen,
            FigletText("Rocks !", font='ogre'),
            screen.height // 2 - 4),
        Cycle(
            screen,
            FigletText("Any questions ?", font='ogre'),
            screen.height // 2 + 2),
        Stars(screen, (screen.width + screen.height) // 2)
    ]
    screen.play([Scene(effects, 500)])

Screen.wrapper(done)  