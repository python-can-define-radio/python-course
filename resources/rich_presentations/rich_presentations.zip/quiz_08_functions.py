from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))          
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

    # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"In Python, which keyword, once used will prevent further code from running in a function?\n\n(a) {M}exit{C}\n(b) {M}stop{C}\n(c) {M}break{C}\n(d) {M}return{C}\n\n", "d"),
        Question(f"What is the difference between parameters and arguments in Python functions?\n\n(a) Python functions can only accept a maximum of two arguments, parameters can be infinite.\n(b) Parameters are the placeholders in the function definition, while arguments are the actual values supplied to the function call.\n(c) Python functions have the ability to summon fascimilies from a parallel dimension as a return value.\n(d) Parameters must be returned, arguments can be ignored.\n\n", "b"),
        Question(f"What is the purpose of the *{VA}args{C} and **{VA}kwargs{C} parameters in Python functions?\n\n(a) This parameter is used to indicate that the function does not accept any arguments or keyword arguments.\n(b) This parameter is used to teleport arguments from one function to another across the classroom, allowing for function calls without the need for conventional data transmission methods.\n(c) This parameter is used to define arguments or keyword arguments that are passed by value rather than by direct reference.\n(d) They allow functions to accept a variable number of positional arguments and keyword arguments, respectively.\n\n", "d"),
        Question(f"What is the default return value of a Python function if no return statement is specified?\n\n(a) {FS}None{C}\n(b) {NU}0{C}\n(c) {NU}1{C}\n(d) None of the above\n\n", "a"),
        Question(f"""What would this code display?
        
    {FS}def{C} {FU}some_thing{C}{GO}({C}{VA}number1, number2{C}{GO}){C}:
        {VA}first_value{C} = {VA}number1{C} + {NU}8{C}
        {VA}second_value{C} = {VA}number2{C} - {NU}5{C}
        {VA}temp_value{C} = {FU}other_thing{C}{GO}({C}{VA}second_value{C}{GO}){C}
        {M}return{C} {VA}temp_value{C}

    {FS}def{C} {FU}other_thing{C}{GO}({C}{VA}another_value{C}{GO}){C}:
        {M}return{C} {GO}({C}{VA}another_value{C} + {NU}5{C}{GO}){C} * {NU}3{C}

    {FU}print{C}{GO}({C}{FU}some_thing{C}{M}({C}{NU}13, 10{C}{M}){C}{GO}){C}                        
        \n(a) {NU}3{C}\n(b) {NU}26{C}\n(c) {NU}30{C}\n(d) {NU}45{C}\n\n""", "c"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()