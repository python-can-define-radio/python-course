from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()

    questions = [
        Question(f'Which mode of the function {FU}open{C}{GO}(){C} will raise a {GR}FileExistsError{C}?\n\n(a) {ST}"r"{C}\n(b) {ST}"w"{C}\n(c) {ST}"a"{C}\n(d) {ST}"x"{C}\n\n', "d"),
        Question(f"""Given this code, {VA}f{C} = {FU}open{C}{GO}({C}{ST}"myfile.txt"{C}, {ST}"r"{C}{GO}){C} which method is used to read one line of a document?\n\n(a) {VA}f{C}.{FU}writeline{C}{GO}(){C}\n(b) {VA}f{C}.{FU}read{C}{GO}(){C}\n(c) {VA}f{C}.{FU}readline{C}{GO}(){C}\n(d) {VA}f{C}.{FU}readlines{C}{GO}(){C}\n\n""", "c"),
        Question(f'Which of these is {BR}not{C} a valid mode argument for the {FU}open{C}{GO}(){C} function?\n\n(a) {ST}"r"{C}\n(b) {ST}"x+"{C}\n(c) {ST}"a"{C}\n(d) {ST}"l"{C}\n\n', "d"),
        Question(f"Which keyword closes a file automatically without explicitly using the .{FU}close{C}{GO}(){C} method?\n\n(a) {M}with{C}\n(b) {M}for{C}\n(c) {M}in{C}\n(d) {M}and{C}\n\n", "a"),
        Question(f"When writing to a file, it is common practice to...\n\n(a) Write in a continuous string.\n(b) Add a new line at the end of the last write.\n(c) Customize the cheddar.\n(d) Close the file before writing to it.\n\n", "b"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()