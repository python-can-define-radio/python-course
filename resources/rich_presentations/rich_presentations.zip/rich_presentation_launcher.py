#!/usr/bin/env python3

from prompt_toolkit.shortcuts import radiolist_dialog
import os
import sys
from pprint import pprint

def main():
    ## main path
    dir_root = "~/Desktop/rich_presentations"
    ## path for testing locally
    # dir_root = "/home/michael.a.hutchings98/Desktop/Hutchings/practice/python_examples_for_class"


    def python_or_sdr():
        return radiolist_dialog(
        title='Rich Presentation Launcher',
        text='Select a module!',
        values=[
            ("Python", "Python"),
            ("SDR", "SDR"),
            ],
            ).run()
    
    
    def quiz_or_lecture():
        return radiolist_dialog(
        title='Rich Presentation Launcher',
        text='Which would you like to do?',
        values=[
            ("Lectures", "Lectures"),
            ("Quizzes", "Quizzes"),
            ],
            ).run()
    

    def act_on_choice(choice: str):
        dir_root_exp = os.path.expanduser(dir_root)
        p = f"{dir_root_exp}/{choice}"
        if not os.path.exists(p):
            print(f"{p} doesn't exist.")
            print(f"Files in {dir_root_exp}:")
            pprint(sorted(os.listdir(dir_root_exp)))
            sys.exit(1)
        os.system(f"python3 {p}")
        
        
    def get_user_choice_python_lecture() -> str:
        return radiolist_dialog(
        title='Main Menu',
        text=f'Choose a Presentation to launch.',
        values=[
            ("lec_01a_prints_inputs_variables.py", "Prints and Inputs"),
            ("lec_01b_02a_02b_formatting_num_sys_operators.py", "Number Systems"),
            ("lec_02c_modules.py", "Modules"),
            ("lec_03a_if_else.py", "IF-Else"),
            ("lec_03b_if_else_common_mistakes.py", "IF-Else common mistakes"),
            ("lec_04a_lists.py", "Lists"),
            ("lec_04c_for_loops.py", "For loops"),
            ("lec_05a_random.py", "Random module"),
            ("lec_05b_while_loops.py", "While loops"),
            ("lec_06a_classes.py", "Dataclasses"),
            ("lec_06b_dictionaries.py", "Dictionaries"),
            ("lec_06c_functions.py", "Functions"),
            ("lec_06e_file_writing.py", "File writing"),
            ],
            ).run()


    def get_user_choice_python_quiz() -> str:
        return radiolist_dialog(
        title='Main Menu',
        text=f'Choose a Quiz to launch.',
        values=[
            ("quiz_01_print_input.py", "Prints and Inputs"),
            ("quiz_02_number_system_operator.py", "Number Systems and Operators"),
            ("quiz_03_if_else.py", "IF Else"),
            ("quiz_04a_lists.py", "Lists"),
            ("quiz_04c_for_loops.py", "For Loops"),
            ("quiz_05a_randomness.py", "Randomness"),
            ("quiz_05b_while_loops.py", "While Loops"),
            ("quiz_06a_dataclasses.py", "Dataclasses"),
            ("quiz_06b_dictionaries.py", "Dictionaries"),
            ("quiz_06c_functions.py", "Functions"),
            ("quiz_06e_file_writing.py", "File Writing"),
            ],
            ).run()
    

    def get_user_choice_sdr_lecture() -> str:
        return radiolist_dialog(
        title='Main Menu',
        text=f'Choose a Presentation to launch.',
        values=[
            ("lec_sdr_01a_intro.py", "Beginnings"),
            ("lec_sdr_02a_modulation.py", "Modulation"),
            ("lec_sdr_03a_sampling.py", "Sampling"),
            ],
            ).run()


    def get_user_choice_sdr_quiz() -> str:
        return radiolist_dialog(
        title='Main Menu',
        text=f'Choose a Quiz to launch.',
        values=[
            ("quiz_sdr_01_intro.py", "Beginnings"),
            ("quiz_sdr_02_modulation.py", "Modulation"),
            ("quiz_sdr_03_sampling.py", "Sampling"),
            ],
            ).run()


    mod = python_or_sdr()
    result = quiz_or_lecture()
    if mod == "Python":
        if result == "Lectures":
            while True:
                choice = get_user_choice_python_lecture()
                act_on_choice(choice)
                if choice == None:
                    main()
                    if choice == None:
                        break
        elif result == "Quizzes":
            while True:
                choice = get_user_choice_python_quiz()
                act_on_choice(choice)
                if choice == None:
                    main()
                    if choice == None:
                        break
    elif mod == "SDR":
        if result == "Lectures":
            while True:
                choice = get_user_choice_sdr_lecture()
                act_on_choice(choice)
                if choice == None:
                    main()
                    if choice == None:
                        break
        elif result == "Quizzes":
            while True:
                choice = get_user_choice_sdr_quiz()
                act_on_choice(choice)
                if choice == None:
                    main()
                    if choice == None:
                        break

if __name__ == "__main__":
    main()    
