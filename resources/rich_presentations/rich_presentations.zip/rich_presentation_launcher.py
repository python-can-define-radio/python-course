#!/usr/bin/env python3

from prompt_toolkit.shortcuts import radiolist_dialog
import os

def main():
    dir_root = "~/Desktop/rich_presentations"


    def act_on_choice(choice: str):
        os.system(f"python3 {dir_root}/{choice}")
        
        
    def get_user_choice() -> str:
        return radiolist_dialog(
                title='Main Menu',
                text=f'Choose a Rich Presentation to launch.',
                values=[
                    ("lec_01a_01b_prints_inputs_variables.py", "Prints and Inputs"),
                    ("lec_02a_02b_number_systems_operators.py", "Number Systems"),
                    ("lec_03a_if_else.py", "IF-Else"),
                    ("lec_03b_if_else_common_mistakes.py", "IF-Else common mistakes"),
                    ("lec_04a_lists.py", "Lists"),
                    ("lec_04b_random.py", "Random module"),
                    ("lec_05a_file_writing.py", "File writing"),
                    ("lec_06a_for_loops.py", "For loops"),
                    ("lec_06b_while_loops.py", "While loops"),
                    ("lec_07a_dictionaries.py", "Dictionaries"),
                    ("lec_08a_b_functions.py", "Functions"),
                ],
            ).run()

    def quiz_or_lecture():
        return radiolist_dialog(
        title='Rich Presentation Launcher',
        text='Which would you like to do?',
        values=[
            ("lectures", "Lectures"),
            ("quizs", "Quiz's"),
        ],
    ).run()

    def run_quiz() -> str:
        return radiolist_dialog(
                title='Main Menu',
                text=f'Choose a Quiz to launch.',
                values=[
                    ("quiz_print_input.py", "Prints and Inputs"),
                    ("quiz_number_system_operator.py", "Number Systems and Operators"),
                ],
            ).run()

    result = quiz_or_lecture()

    if result == "lectures":
        while True:
            choice = get_user_choice()
            act_on_choice(choice)
    elif result == "quizs":
        while True:
            choice = run_quiz()
            act_on_choice(choice)

if __name__ == "__main__":
    main()
    
