from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print("Incorrect", style="red")
                time.sleep(1)
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"Which option gives you a random float between 0 and 1?\n\n(a) [green]random{C}.[pale_turquoise1]random[gold1](){C}{C}\n(b) [green]random{C}.[pale_turquoise1]randrange[gold1]([#B5CEA8]0,1{C}){C}{C}\n(c) [green]random{C}.[pale_turquoise1]uniform[gold1](){C}{C}\n(d) [green]random{C}.[pale_turquoise1]getrandbits[gold1]([#B5CEA8]8{C}){C}{C}\n\n", "a"),
        Question("""Which expression most likely resulted in the following?
                   
    Result: -4.0025131479634455                
    \n(a) [wheat1]print[/][gold1]([/][blue]f[/][#ce9178]"Result:[/] [magenta]{[/][green]random[/].[pale_turquoise1]uniform[/][blue]([/][#B5CEA8]-5, 0[/][blue])[/][magenta]}[/][#ce9178]"[/][gold1])[/]\n(b) [wheat1]print[/]([green]random[/].[pale_turquoise1]randrange[/][magenta]([/][#B5CEA8]-5, 0, .1[/][magenta])[/][gold1])[/]\n(c) [green]random[/].[pale_turquoise1]getrandbits[/][gold1]([/][#B5CEA8]16[/][gold1])[/]\n(d) [wheat1]print[/][gold1]([/][blue]f[/][#ce9178]"Result:[/] [magenta]{[/][green]random[/].[pale_turquoise1]choice[/][blue]([/][#B5CEA8]-5, 0[/][blue])[/][magenta]}[/][#ce9178]"[/][gold1])[/]\n\n""", "a"),
        Question(f"""What does the 5 represent in this expression?
                   
    {GR}random{C}.{ST}randrange{C}{GO}({C}{NU}25, 75, 5{C}{GO}){C}                
    \n(a) stop value\n(b) range value\n(c) step value\n(d) start value\n\n""", "c"),
        Question(f"""What are the possible values of y?
                   
    {VA}x{C} = {GR}random{C}.{VA}random{C}{GO}(){C}
    {VA}{C} = {VA}x{C} + {NU}3{C}
    {FU}print{C}{GO}({C}{VA}y{C}{GO}){C}
    \n(a) between 0 and 4\n(b) between 3 and 4\n(c) 3, 3.5, 4\n(d) None of these\n\n""", "b"),
          Question(f"""Which method should I use to get 4 elements from the following list randomly?
                   
    {VA}samplelist{C} = {GO}[{C}{NU}20, 40, 60, 80, 100, 120, 140, 160, 180, 200{C}{GO}]{C}               
    \n(a) {FU}print{C}{GO}({C}{GR}random{C}.{VA}choice{C}{M}({C}{VA}samplelist{C}, {NU}4{C}{M}){C}{GO}){C}\n(b) {GR}random{C}.{VA}uniform{C}{GO}({C}{NU}4{C}{GO}){C}\n(c) {GR}random{C}.{VA}sample{C}{GO}({C}{NU}4{C}{GO}){C}\n(d) {FU}print{C}{GO}({C}{GR}random{C}.{VA}sample{C}{M}({C}{VA}samplelist{C}, {NU}4{C}{M}){C}{GO}){C}\n\n""", "d"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()