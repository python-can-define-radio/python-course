from rich.console import Console
from rich.markdown import Markdown
from rich_presentation_helpers import pip_install_for_presentation, auto_resize
import matplotlib.pyplot as plt
from pcdr import makeWave, ook_modulate
import numpy as np



pip_install_for_presentation()
# auto_resize()


console = Console()
print = console.print
input = console.input
THEME = "zenburn"


def md(*args, **kwargs):
    return Markdown(*args, code_theme=THEME, inline_code_theme=THEME, inline_code_lexer="python3", **kwargs)


def printwait(*args, **kwargs):
    print(*args, **kwargs)
    input()

console.clear()
##########################################
printwait(md(f"""
# Modulation 

ℹ️  Lets start with basic modulation, what is it?
              


"""))

printwait(f"""Modulation is an attempt to convey intelligence (information) utilizing a medium.
          """)
print("What is happening in this diagram?")


##showing basic OOK
modulated = ook_modulate([1, 0, 1, 0, 1, 0, 1, 1], bit_length=25)
timestamps, wave = makeWave(100, 4, "real", num=200)
upconverted = modulated * wave
y = np.sin(timestamps)
fig = plt.figure(figsize=(15, 10))
plt.subplot(311)
plt.plot(timestamps, wave, "*-", color="blue", linestyle= "-", markersize=5, linewidth=3, label="sine")
plt.subplot(312)
plt.plot(modulated, "*-", markersize=5, color="gold")
plt.subplot(313)
plt.plot(timestamps, upconverted, "*-", markersize=5, color="green")
plt.show()

console.clear()
##########################################
printwait(md(f"""
# Modulation 

ℹ️  What is this an example of?
    
Notice the resulting frequency is not the same frequency, why?
              


"""))

##showing aliasing (undersampling)
modulated = ook_modulate([1, 0, 1, 0, 1, 0, 1, 1], bit_length=25)
timestamps, wave = makeWave(100, 4, "real", num=200)
timestamps2, wave2 = makeWave(25, 4, "real", num=200)
upconverted = modulated * wave
upconverted2 = modulated * wave2
y = np.sin(timestamps)
fig = plt.figure(figsize=(15, 10))
plt.subplot(311)
plt.plot(timestamps, wave, "*-", color="blue", linestyle= "-", markersize=5, linewidth=3, label="sine")
plt.subplot(312)
plt.plot(modulated, "*-", markersize=5, color="gold")
plt.subplot(313)
plt.plot(timestamps2, upconverted2, "*-", markersize=5, color="green")
plt.show()
          

console.clear()
##########################################
printwait(md(f"""

ℹ️  

"""))            

printwait(md(f"""


"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  

"""))            


printwait(md(f"""
             
"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  

"""))            

console.clear()
##########################################
printwait(md(f"""

ℹ️  

""")) 

console.clear()
##########################################
printwait(md(f"""

ℹ️  

""")) 

console.clear()
##########################################
from asciimatics.screen import Screen
from asciimatics.scene import Scene
from asciimatics.effects import Cycle, Stars
from asciimatics.renderers import FigletText
 

def done(screen):
    effects = [
        Cycle(
            screen,
            FigletText("Python", font='ogre'),
            screen.height // 2 - 10),
        Cycle(
            screen,
            FigletText("Rocks !", font='ogre'),
            screen.height // 2 - 4),
        Cycle(
            screen,
            FigletText("Any questions ?", font='ogre'),
            screen.height // 2 + 2),
        Stars(screen, (screen.width + screen.height) // 2)
    ]
    screen.play([Scene(effects, 500)])

Screen.wrapper(done)  