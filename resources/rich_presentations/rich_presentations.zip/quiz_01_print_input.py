from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print("Incorrect", style="red")
                time.sleep(1)
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"What does print do?\n\n(a) Outputs the designated text to the terminal window.\n(b) Sends the text to a physical printer.\n(c) Allow the user to type a response in the terminal window.\n(d) Nothing\n\n", "a"),
        Question(f"Input...\n\n(a) displays text only.\n(b) displays text, and waits (blocks) until the user types a response.\n(c) only allows the user to type a response.\n(d) writes data to a file.\n\n", "b"),
        Question(f"Which of these would be the poorest choice of variable name?\n\n(a) {VA}cheese{C}\n(b) {VA}name{C}\n(c) {VA}input{C}\n(d) {VA}age{C}\n\n", "c"),
        Question("Which characters are required when running a function, such as print or input?\n\n(a) [gold1][][/]\n(b) [magenta]{}[/]\n(c) ::\n(d) [gold1]()[/]\n\n", "d"),
        Question(f"Which operator is used to define a variable?\n\n(a) =\n(b) ==\n(c) <=\n(d) %\n\n", "a"),
    ]

    run_quiz(questions)
    print()
    
if __name__ == '__main__':
     main()
