from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))             
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"What is a {M}while{C} loop's primary purpose?\n\n(a) A programming vortex that sucks your code into an endless whirlpool of repetition, where time stands still and your program loops endlessly, like a hamster on a wheel, forever chasing its own tail.\n(b) A control flow statement that allows a block of code to be executed repeatedly as long as a specified condition is true.\n(c) A way to iterate over elements of a list, providing access to each element individually.\n(d) A while loop is a built-in function for performing mathematical calculations.\n\n", "b"),
        Question(f"An infinite loop may occur if...\n\n(a) unicorns invade the code and start dancing on the keyboard, causing an unpredictable sequence of characters that somehow always satisfy the loop condition.\n(b) The while loop uses an if-else statement.\n(c) The condition is not python specific.\n(d) The exit condition is never met.\n\n", "d"),
        Question(f"""What is the output of the following Python code??
                 
    {VA}count{C} = {NU}0{C}
    {M}while{C} {VA}count{C} < {NU}3{C}:
        {FU}print{C}{GO}({C}{ST}"Hello"{C}{GO}){C}
        {VA}count{C} += {NU}1{C}
    {FU}print{C}{GO}({C}{ST}"Goodbye"{C}{GO}){C}                          
        \n(a) It will print {ST}"Goodbye"{C} before printing {ST}"Hello"{C} 3 times.\n(b) It will print {ST}"Hello"{C} after printing {ST}"Goodbye"{C}, followed by two more {ST}"Hello"{C} outputs.\n(c) Prints {ST}"Hello"{C} three times and then prints {ST}"Goodbye"{C}.\n(d) It will print {ST}"Hello"{C} four times consecutively before printing {ST}"Goodbye"{C}.\n\n""", "c"),
        Question(f"""Given the following code, which of these inputs could you use to exit the loop?
                 
    {VA}choice{C} = {FU}input{C}{GO}({C}{ST}"Guess the word. "{C}{GO}){C}
    {M}while{C} {VA}choice{C}.{FU}lower{C}{GO}(){C} != {ST}"Banana"{C}:
        {VA}choice{C} = {FU}input{C}{GO}({C}{ST}"Guess the word. "{C}{GO}){C}                             
        \n(a) None of these\n(b) BANANA\n(c) Banana\n(d) Widdershins\n\n""", "a"),
        Question(f"What programming concept does a while loop primarily represent in Python??\n\n(a) Declaration\n(b) Assignment\n(c) Arithmetic\n(d) Iteration\n\n", "d"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()