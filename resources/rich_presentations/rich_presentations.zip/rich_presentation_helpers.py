import os



M = "[magenta]"
BR = "[bold red]"
FS = "[blue]"
FU = "[wheat1]"
GO = "[gold1]"
GR = "[green]"
NU = "[#B5CEA8]"
ST = "[#ce9178]"
VA = "[pale_turquoise1]"
C = "[/]"
OB = "[magenta]{[/]"
CB = "[magenta]}[/]"
LB = "[gold1]{[/]"
RB = "[gold1]}[/]"


def pip_install_for_presentation():
    try:
        import pyautogui
        import asciimatics 
    except (ImportError, ModuleNotFoundError):
        c = input("Would you like to automatically install these python packages (asciimatics, pyautogui) ? y/n: ")
        if c == "y":
            os.system("pip install pyautogui asciimatics")
        else:
            print("These packages are not required for functionality to view the presentation.")
            pass
            

def auto_resize():
    try:
        import subprocess
        import pyautogui
        if os.environ.get('TERM_PROGRAM') == 'vscode':
            ## vscode toggle file explorer window
            pyautogui.hotkey("Ctrl", "b")
            ## my hotkey for maximized terminal window
            pyautogui.hotkey("Ctrl", "Alt", "f")
            ## vscode fullscreen hotkey
            pyautogui.hotkey("f11")
            ## change focus to vscode terminal
            pyautogui.hotkey("Ctrl", "`")
        else:
            result = subprocess.run(["resize -s 50 200"], shell=True)
            pyautogui.hotkey("Ctrl","Shift","+")
            pyautogui.hotkey("Ctrl","Shift","+")
    except (ModuleNotFoundError, ImportError):
        pass