from rich.console import Console
from rich.markdown import Markdown
from rich_presentation_helpers import pip_install_for_presentation, auto_resize



pip_install_for_presentation()
# auto_resize()


console = Console()
print = console.print
input = console.input
THEME = "zenburn"


def md(*args, **kwargs):
    return Markdown(*args, code_theme=THEME, inline_code_theme=THEME, inline_code_lexer="python3", **kwargs)


def printwait(*args, **kwargs):
    print(*args, **kwargs)
    input()


console.clear()

##########################################
printwait(md("""
# Importing modules

ℹ️  Modules are pre-written python code (a code library) designed for specific purposes.  
Some modules like `math` come pre-installed with your python installation and can be used immediately.  
Other modules like `guizero` are available on PYPI but need to be downloaded before you can use them.
             
When importing modules, there are a few approaches you can use:
""")) 

printwait(md("""
Import the whole module:\n
```python3
import math
print(math.sqrt(5))
```
""")) 

import math
print(math.sqrt(5))

printwait() 

printwait(md("""
Import the whole module, and give it another name ("alias"):\n
```python3
import math as m
print(m.sqrt(5))
```
""")) 

import math as m
print(m.sqrt(5))

printwait() 

console.clear()

printwait(md("""
# Importing modules

Import everything from the module:\n
```python3
from math import *
print(sqrt(5))
```
"""))

from math import *
print(sqrt(5))

printwait()

printwait(md("""
Import one function:\n
```python3
from math import sqrt
print(sqrt(5))
```
"""))

from math import sqrt
print(sqrt(5), "\n")

printwait(md("Last example. Hit Enter to exit.")) 

console.clear()
##########################################
from asciimatics.screen import Screen
from asciimatics.scene import Scene
from asciimatics.effects import Cycle, Stars
from asciimatics.renderers import FigletText
 

def done(screen):
    effects = [
        Cycle(
            screen,
            FigletText("Python", font='ogre'),
            screen.height // 2 - 10),
        Cycle(
            screen,
            FigletText("Rocks !", font='ogre'),
            screen.height // 2 - 4),
        Cycle(
            screen,
            FigletText("Any questions ?", font='ogre'),
            screen.height // 2 + 2),
        Stars(screen, (screen.width + screen.height) // 2)
    ]
    screen.play([Scene(effects, 500)])

Screen.wrapper(done)

