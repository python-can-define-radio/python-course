from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        Incorrect:      ❌  {question}

        Correct:        ✅  {item.answer}


        Hit enter for next question.
        """, style="red")
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"Which of the following statements about dictionaries in Python is true?\n\n(a) Dictionaries in Python are ordered collections.\n(b) Keys in a dictionary must be of the same data type.\n(c) A dictionary can have duplicate keys but not duplicate values.\n(d) The {FU}len{C}{GO}(){C} function can't be used to find the number of elements in a dictionary.\n\n", "c"),
        Question(f"Which method would eliminate an item from a dictionary?\n\n(a) .{FU}delete{C}{GO}(){C}\n(b) .{FU}pop{C}{GO}(){C}\n(c) .{FU}remove{C}{GO}(){C}\n(d) .{FU}discard{C}{GO}(){C}\n\n", "b"),
        Question(f"Which method will result in a list of tuples containing the key and value of each dictionary entry?\n\n(a) {FU}items{C}{GO}(){C}\n(b) {FU}values{C}{GO}(){C}\n(c) {FU}keys{C}{GO}(){C}\n(d) {FU}enumerate{C}{GO}(){C}\n\n", "a"),
        Question(f"Which Python method allows you to update a dictionary with key-value pairs from another dictionary, overwriting existing keys and adding new ones if necessary??\n\n(a) {FU}extend{C}{GO}(){C}\n(b) {FU}append{C}{GO}(){C}\n(c) {FU}update{C}{GO}(){C}\n(d) {FU}add{C}{GO}(){C}\n\n", "c"),
        Question(f"Which of the following methods can be used to check if a key exists in a dictionary in Python?\n\n(a) .{FU}check_key{C}{GO}(){C}\n(b) {FU}in{C}\n(c) .{FU}has_key{C}{GO}(){C}\n(d) {FU}contains{C}\n\n", "b"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()