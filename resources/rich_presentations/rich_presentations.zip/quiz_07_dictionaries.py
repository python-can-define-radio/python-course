from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"Which of the following statements about dictionaries in Python is true?\n\n(a) Dictionaries in Python are precipitation collectors.\n(b) Keys in a dictionary must be of the same data type.\n(c) A dictionary can have duplicate values but not duplicate keys.\n(d) Like lists, dictionary elements can be accessed using the position index.\n\n", "c"),
        Question(f"""Given the following dictionary which answer should you use?
                 
    {VA}jobname{C} = {LB}
        {ST}"Frank"{C}: {ST}"Programmer"{C},
        {ST}"Jim"{C}: {ST}"Linguist"{C},
        {ST}"Melissa"{C}: {ST}"IT Consultant"{C},
        {ST}"Henry"{C}: {ST}"Linguist"{C},
        {ST}"Jane"{C}: {ST}"Programmer"{C},
        {ST}"George"{C}: {ST}"IT Consultant"{C}
        {RB}
    {VA}name{C} = {FU}input{C}{GO}({C}{ST}"Enter employee name. "{C}{GO}){C}
    {FU}print{C}{GO}({C}{FS}f{C}{ST}"That employee's job is {OB}_______{CB}"{C}{GO}){C}
                          
        \n(a) {VA}jobname{C}{FS}[{C}{OB}{VA}name{C}{CB}{FS}]{C}\n(b) {VA}jobname{C}{FS}[{C}{VA}name{C}{FS}]{C}\n(c) {VA}jobname{C}{FS}[{C}{ST}'name'{C}{FS}]{C}\n(d) {VA}jobname{C}{GO}({C}{VA}name{C}{GO}){C}\n\n""", "b"),
        Question(f"""Which would check if {ST}"Programmer"{C} is one of the values in this dictionary?
                 
        {VA}jobname{C} = {LB}
        {ST}"Frank"{C}: {ST}"Programmer"{C},
        {ST}"Jim"{C}: {ST}"Linguist"{C},
        {ST}"Melissa"{C}: {ST}"IT Consultant"{C},
        {ST}"Henry"{C}: {ST}"Linguist"{C},
        {ST}"Jane"{C}: {ST}"Programmer"{C},
        {ST}"George"{C}: {ST}"IT Consultant"{C}
        {RB}   
        if ________:
            print("There is at least one Programmer at this company.")
                 
        \n(a) "Programmer" in jobnames \n(b) "Programmer" in jobnames.keys() \n(c) "Programmer" in jobnames.values() \n(d) "Programmer" in jobnames.items() \n\n""", "c"),
        Question(f"Which method will result in a list of tuples containing the key and value of each dictionary entry?\n\n(a) {FU}items{C}{GO}(){C}\n(b) {FU}values{C}{GO}(){C}\n(c) {FU}keys{C}{GO}(){C}\n(d) {FU}enumerate{C}{GO}(){C}\n\n", "a"),
        Question(f"Which of the following can be used to check if a key exists in a dictionary in Python?\n\n(a) .{FU}check_key{C}{GO}(){C}\n(b) {FU}in{C}\n(c) .{FU}has_key{C}{GO}(){C}\n(d) {FU}contains{C}\n\n", "b"),
    ]

    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()