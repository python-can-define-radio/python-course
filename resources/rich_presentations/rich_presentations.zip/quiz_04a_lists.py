from rich.console import Console
from rich import print
from rich_presentation_helpers import * 
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            console.print(item.prompt,highlight=False)
            question = prompt("Answer: ", validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print(f"""
        [red]Incorrect:      ❌  {question}[/]

        [green]Correct:        ✅  {item.answer}[/]


        Hit enter for next question.
        """)
                input()
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
        Question(f"What keyword should be used to check if a list contains an item?\n\n(a) {M}maybe{C}\n(b) {M}and{C}\n(c) {M}for{C}\n(d) {M}in{C}\n\n", "d"),
        Question(f"""What would this code print?
                   
    {VA}genericlist{C} = {GO}[{C}{M}[{C}{ST}"Hillary"{C}, {NU}25{C}, {NU}7{C}{M}]{C}, {M}[{C}{ST}"Graham"{C}, {NU}22{C}, {NU}4{C}{M}]{C}, {M}[{C}{ST}"Morris"{C}, {NU}32{C}, {NU}12{C}{M}]{C}{GO}]{C}
    {FU}print{C}{GO}({C}{VA}genericlist{C}{M}[{C}{NU}2{C}{M}][{C}{NU}0{C}{M}][{C}{NU}2{C}:{M}]{C}{GO}){C}    
                                  
        \n\n(a) rris\n(b) aham\n(c) llary\n(d) 12\n\n""", "a"),
        Question(f"""Given the following code, which command would add {ST}"novacorps18"{C} to the list?
                   
    {VA}usernames{C} = {GO}[{C}{ST}"brainchild32"{C}, {ST}"thedarkpineapple"{C}, {ST}"vibeman"{C}, {ST}"godly fishy"{C}{GO}]{C}
    {VA}user{C} = {ST}"novacorps18"{C}
                                  
        \n\n(a) {VA}usernames{C}.{FU}append{C}{GO}({C}{VA}user{C}{GO}){C}\n(b) {VA}user{C}.{FU}append{C}{GO}({C}{VA}username{C}{GO}){C}\n(c) {VA}usernames{C}.{FU}adduser{C}{GO}(){C}\n(d) {VA}usernames{C}.{FU}add{C}{GO}({C}{VA}user{C}{GO}){C}\n\n""", "a"),
        Question(f"In Python, the items of a list can be accessed by ____. The numbering starts at ___.\n\n(a) marking, one\n(b) Cuisinart, zero\n(c) float, one\n(d) index, zero\n\n""", "d"),
        Question(f"""Given the following list what expression would print the letter t of python?
                   
    {VA}x{C} = {GO}[{C}{NU}10{C}, {M}[{C}{NU}3.141, 20,{C} {FS}[{C}{NU}30{C}, {ST}'python'{C}, {NU}2.718{C}{FS}]{C}{M}]{C}, {ST}'rocks'{C}{GO}]{C}
            
        \n\n(a) {FU}print{C}{GO}({C}{VA}x{C}{M}[{C}{ST}"t"{C} {M}in{C} {ST}"python"{C}{M}]{C}{GO}){C}\n(b) {FU}print{C}{GO}({C}{VA}x{C}{M}[{C}{NU}1{C}{M}][{C}{NU}2{C}{M}][{C}{NU}1{C}{M}][{C}{NU}2{C}{M}]{C}{GO}){C}\n(c) {FU}print{C}{GO}({C}{VA}x{C}{M}[{C}{NU}1{C}{M}][{C}{NU}2{C}{M}][{C}{NU}1{C}:{M}]{C}{GO}){C}\n(d) {FU}print{C}{GO}({C}{VA}x{C}{M}[{C}{NU}1{C}{M}][{C}{NU}2{C}{M}][{C}{NU}1{C}{M}][{C}:-{NU}1{C}{M}]{C}{GO}){C}\n\n""", "b"),
    ]


    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()