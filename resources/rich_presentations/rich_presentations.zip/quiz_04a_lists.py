from rich.console import Console
# from rich_presentation_helpers import auto_resize
from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt
from dataclasses import dataclass
from typing import List
import time


def main():
    @dataclass
    class Question:
        prompt: str
        answer: str


    class InputValidator(Validator):
        def __init__(self, valfunc):
            self.valfunc = valfunc


        def validate(self, document):
            text = document.text
            valresult = self.valfunc(text)
            if valresult != "":
                raise ValidationError(message=valresult)


    def only_a_b_c_d(x: str) -> str:
        if x in ["a", "b", "c", "d"]:
            return ""
        else:
            return "Valid options; a, b, c, d"
        
    def only_y_n(x: str) -> str:
        if x in ["y", "n"]:
            return ""
        else:
            return "Valid options; y or n"


    def run_quiz(questions: List[Question]):
        score = 0
        for item in questions:
            print()
            question = prompt(item.prompt, validator=InputValidator(only_a_b_c_d))
            if question == item.answer:
                score += 1
                console.print("Correct", style="green")
                time.sleep(1)
            elif question != item.answer:
                console.print("Incorrect", style="red")
                time.sleep(1)
            console.clear()
        print()
        ave = (score/len(questions))*100
        if ave > 70:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="green")
            print("Congratulations you passed.")
            if score != 5:
                resp = prompt("I see you did not get a perfect score would you like to take the quiz again? ", validator=InputValidator(only_y_n))            
                if resp == "y":
                    main()
        else:
            console.print(f"you got {score} out of {len(questions)} which is {ave:.2f}%", style="red")
            input("Lets try again hit enter to restart the quiz.")
            main()

     # auto_resize()
    console = Console()
    console.clear()


    questions = [
          Question("What keyword should be used to find an item from a list of items?\n\n(a) maybe\n(b) and\n(c) for\n(d) in\n\nAnswer: ", "d"),
          Question("""What would this code print?
                   
    genericlist = [["Hillary", 25, 7], ["Graham", 22, 4], ["Morris", 32, 12]]
    print(genericlist[2][0][2:])    
                                  
    \n\n(a) rris\n(b) aham\n(c) llary\n(d) 12\n\nAnswer: """, "a"),
          Question("""Given the following code which command would add \"user\" to the list?
                   
    usernames = ["brainchild32", "thedarkpineapple", "vibeman", "godly fishy"]
    user = "novacorps18"
                                  
    \n\n(a) usernames.append(user)\n(b) user.append(username)\n(c) usernames.adduser()\n(d) usernames.add(user)\n\nAnswer: """, "a"),
          Question("What is it called when we number positions of a list?\n\n(a) zero-marking\n(b) Cuisinart-indexing\n(c) integer indexing\n(d) zero-indexing\n\nAnswer: ", "d"),
          Question("""Given the following list what expression would print the letter t of python?
                   
    x = [10, [3.141, 20, [30, 'python', 2.718]], 'rocks']
            
    \n\n(a) print(x["t" in "python"])\n(b) print(x[1][2][1][2])\n(c) print(x[1][2][1:])\n(d) print(x[1][2][1][:-1])\n\nAnswer: """, "b"),
    ]


    run_quiz(questions)
    print()

if __name__ == '__main__':
     main()