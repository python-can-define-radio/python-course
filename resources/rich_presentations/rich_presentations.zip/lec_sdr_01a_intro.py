from rich.console import Console
from rich.markdown import Markdown
from rich_presentation_helpers import pip_install_for_presentation, auto_resize



pip_install_for_presentation()
# auto_resize()


console = Console()
print = console.print
input = console.input
THEME = "zenburn"


def md(*args, **kwargs):
    return Markdown(*args, code_theme=THEME, inline_code_theme=THEME, inline_code_lexer="python3", **kwargs)


def printwait(*args, **kwargs):
    print(*args, **kwargs)
    input()

console.clear()
##########################################
printwait(md(f"""
# Introduction to SDR's

ℹ️  Lets start with a basic transmitter and receiver.
              
"""))            

printwait(md(f"""

"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  

"""))            

printwait(md(f"""

"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  Taken a step further we can pass a variable in as the argument.
              
"""))            

printwait(md(f"""
             
"""))

console.clear()
##########################################
printwait(md(f"""

ℹ️  
             
"""))            

console.clear()
##########################################
printwait(md(f"""

ℹ️  

""")) 

console.clear()
##########################################
printwait(md(f"""

ℹ️  
             
""")) 

console.clear()
##########################################
from asciimatics.screen import Screen
from asciimatics.scene import Scene
from asciimatics.effects import Cycle, Stars
from asciimatics.renderers import FigletText
 

def done(screen):
    effects = [
        Cycle(
            screen,
            FigletText("Python", font='ogre'),
            screen.height // 2 - 10),
        Cycle(
            screen,
            FigletText("Rocks !", font='ogre'),
            screen.height // 2 - 4),
        Cycle(
            screen,
            FigletText("Any questions ?", font='ogre'),
            screen.height // 2 + 2),
        Stars(screen, (screen.width + screen.height) // 2)
    ]
    screen.play([Scene(effects, 500)])

Screen.wrapper(done)  