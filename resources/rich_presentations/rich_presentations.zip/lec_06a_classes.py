import time
from rich.layout import Layout
from rich.panel import Panel
from rich.live import Live
from rich.console import Console
from rich.markdown import Markdown
from rich_presentation_helpers import pip_install_for_presentation, auto_resize



pip_install_for_presentation()
# auto_resize()


console = Console()
print = console.print
input = console.input
THEME = "zenburn"


layout = Layout()
layout.split_row(
    Layout(name="left"),
    Layout(name="right"),
)
layout["right"].split_column(
    Layout(name="top"),
    Layout(name="bottom"),
)
layout["left"].ratio = 2
layout["top"].ratio = 1


def md(*args, **kwargs):
    return Markdown(*args, code_theme=THEME, inline_code_theme=THEME, inline_code_lexer="python3", **kwargs)


def printwait(*args, **kwargs):
    print(*args, **kwargs)
    input()


console.clear()
#################Basic dataclass#################

layout["left"].update(md("""
# What is a dataclass?

ℹ️  A class is a code template for creating objects.  
    Objects have member variables and have behaviour associated with them.  
    In python a class is created by the keyword class.

"""))

layout["top"].update(Panel(md("""
```python3
from dataclasses import dataclass

@dataclass
class Computer:
    brand: str
    model: str
    speed: str
    storage_capacity: str
```
"""), title="[blue]Our First Dataclass[/]"))

layout["bottom"].update(md("""

"""))


with Live(layout):
    input()

layout["left"].update(md("""
# Dataclasses 

ℹ️  A class is a code template for creating objects.  
    Objects have member variables and have behaviour associated with them.  
    In python a class is created by the keyword class.

To create the object you `call` the class and define the associated attributes as arguments of the class which we store into a variable.                   
```python3
comp = Computer("Dell", "Wyse 5070", "800 Mhz", "1 TB")
print(comp.model)
```
Now because of that definition we can recall data from a specific object like this `comp.model`.                        
Lets try it.
"""))

with Live(layout):
    input()

layout["left"].update(md("""
# Dataclasses 

ℹ️  A class is a code template for creating objects.  
    Objects have member variables and have behaviour associated with them.  
    In python a class is created by the keyword class.

To create the object you `call` the class and define the associated attributes as parameters of the class which we store into a variable.
```python3
comp = Computer("Dell", "Wyse 5070", "800 Mhz", "1 TB", 5)
print(comp.model)
```

Now because of that definition we can recall data from a specific object like this `comp.model`.
Lets try it.
                         
```python3
Wyse 5070
```                         
"""))

with Live(layout):
    input()


console.clear()
##########################################
from asciimatics.screen import Screen
from asciimatics.scene import Scene
from asciimatics.effects import Cycle, Stars
from asciimatics.renderers import FigletText
 

def done(screen):
    effects = [
        Cycle(
            screen,
            FigletText("Python", font='ogre'),
            screen.height // 2 - 10),
        Cycle(
            screen,
            FigletText("Rocks !", font='ogre'),
            screen.height // 2 - 4),
        Cycle(
            screen,
            FigletText("Any questions ?", font='ogre'),
            screen.height // 2 + 2),
        Stars(screen, (screen.width + screen.height) // 2)
    ]
    screen.play([Scene(effects, 500)])

Screen.wrapper(done)    