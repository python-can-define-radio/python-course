from rich.panel import Panel
from rich.live import Live
import time
import Encounters
from end_credits import end_credits
from ui import make_layout, render_equipment, render_stats
from gameplay_messages import set_gameplay_message, show_title, add_gameplay_message, show_scroll
from intro import run_opening_scene
import Items
from save_game import load_player

## not implemented
## item store (to clear out unused inventory or to buy items that cannot be found) Items store function 
## should be able to repeat a tier?? maybe not enough gear to progress or gold to purchase gear.
## possibly add roomCounter to the player dictionary so it will save to the toml file to track how far through that tier you have progressed
## restart upon death not working
## have to select continue twice for some reason


def item_lookup(item_name):
    cls = Items.item_registry.get(item_name)
    if cls is None:
        set_gameplay_message(f"[WARN] Unknown item: {item_name}", layout)
        return None
    return cls()



def create_character(live):
    set_gameplay_message("Greetings, what are you called? ", layout)
    name = input()
    set_gameplay_message(f"What is your background {name}?", layout)
    add_gameplay_message("1. Warrior 2. Rogue 3. Mage ", layout)
    select = input()
    set_gameplay_message("You will be able to see your Player stats and equipped items on the right of the screen ------------------> ", layout)
    time.sleep(3)
    # for i in range(5, 0, -1):
    #     add_gameplay_message(f"Game begins in: {i}", layout)
    #     time.sleep(1)
    #     set_gameplay_message("", layout)
    return name, select


console, layout = make_layout()
console.clear()

def main():
    skip = run_opening_scene()
    player = None
    with Live(layout, console=console) as live:  
        layout["top_left"].update(show_title())
        layout["top_right"].update(Panel("", title="Player Stats", border_style="cyan"))
        layout["bottom_left"].update(Panel("", title="Gameplay", border_style="black"))
        layout["bottom_right"].update(Panel("",title="Equipped Items", border_style="cyan"))
        set_gameplay_message("You will not be able to see your typing have no fear adventurer it is working. ", layout)
        add_gameplay_message("Would you like to load a saved game or continue type L or C? ", layout)
        load_existing = input().strip().lower()
        if load_existing == "l":
            set_gameplay_message("Enter your characters name.", layout)
            name = input().strip().lower()
            player = load_player(name, item_lookup)
        if not player:
            name, select = create_character(live)
        else:
            inventory = {}  # Optional: Save/load this too
            layout["top_right"].update(render_stats(player))
            layout["bottom_right"].update(render_equipment(player))
            game = Encounters.gameplayLoop(player, 0, inventory, console, layout)
            if game == "Victory":
                end_credits()
            return

        if select == "1":
            playerclass = "Warrior"
            level = 1
            AC = 0
            STR = 5
            DEX = 2
            INT = 1
            CON = 5
            LUK = 1
            HP = 140
            maxHP = 140
            MP = 0
            maxMP = 0
            Gold = 20
            weapon = Items.rustySword()
            helm = None
            chest = None
            gloves = None
            legs = None
            boots = None
            EXP = 0
            levelXP = 100
            current_tier = 1
        elif select == "2":
            playerclass = "Rogue"
            level = 1
            AC = 0
            STR = 2
            DEX = 5
            INT = 1
            CON = 3
            LUK = 3
            HP = 110
            maxHP = 110
            MP = 0
            maxMP = 0
            Gold = 20
            weapon = Items.boneDagger()
            helm = None
            chest = None
            gloves = None
            legs = None
            boots = None
            EXP = 0
            levelXP = 100
            current_tier = 1
        elif select == "3":
            playerclass = "Mage"
            level = 1
            AC = 0
            STR = 1
            DEX = 3
            INT = 7
            CON = 2
            LUK = 1
            HP = 80
            maxHP = 80
            MP = 110
            maxMP = 110
            Gold = 20
            weapon = Items.woodenStaff()
            helm = None
            chest = None
            gloves = None
            legs = None
            boots = None
            EXP = 0
            levelXP = 100
            current_tier = 1
        else:
            playerclass = "Warrior"
            level = 1
            HP = 100
            maxHP = 100
            MP = 0
            maxMP = 0
            AC = 0
            STR = 5
            DEX = 3
            INT = 1
            CON = 4
            LUK = 1
            Gold = 20
            weapon = Items.rustySword()
            helm = None
            chest = None
            gloves = None
            legs = None
            boots = None
            EXP = 0
            levelXP = 100
            current_tier = 1

        player = {
            "Name": name,
            "Class": playerclass,
            "Level": level,
            "HP": HP,
            "maxHP": maxHP,
            "MP": MP,
            "maxMP": maxMP,
            "AC": AC,
            "STR": STR,
            "DEX": DEX,
            "INT": INT,
            "CON": CON,
            "LUK": LUK,
            "Gold": Gold,
            "EXP": EXP,
            "levelXP": levelXP,
            "Current Tier": current_tier,
            "Equipped":{"Weapon": weapon,
            "Helmet": helm,
            "Chest": chest,
            "Gloves": gloves,
            "Legs": legs,
            "Boots": boots},
    }
        if name == "":
            player["Name"] = "Anonymous"
        inventory = {}
        layout["top_right"].update(render_stats(player))
        layout["bottom_right"].update(render_equipment(player))
        game = Encounters.gameplayLoop(player, 0, inventory, console, layout)
    if game == "Victory":
        end_credits()
    print(">>> Game loop ended")


if __name__ == "__main__":
    try:
        main()
    except Exception as e:
        print(f"[ERROR] {e}")
    finally:
        input("Press Enter to close...")
