import toml
import os

SAVE_FOLDER = "saves"

def save_player(player):
    """Save the player dictionary to a TOML file using their name."""
    os.makedirs(SAVE_FOLDER, exist_ok=True)
    filename = f"{SAVE_FOLDER}/{player['Name'].strip().lower().replace(' ', '_')}.toml"

    # Serialize equipped items by name only
    equipped = {
        k: v.name if v else None
        for k, v in player["Equipped"].items()
    }

    player_copy = player.copy()
    player_copy["Equipped"] = equipped

    with open(filename, "w") as f:
        toml.dump(player_copy, f)
    # print(f"Game saved to {filename}")


def load_player(name, item_lookup):
    """Load a saved player by name."""
    filename = f"{SAVE_FOLDER}/{name.strip().lower().replace(' ', '_')}.toml"
    if not os.path.exists(filename):
        # print(f"No save file found for {name}")
        return None

    with open(filename, "r") as f:
        player = toml.load(f)

    # Reconstruct equipped items from names using lookup function
    equipped = {
        k: item_lookup(v) if v else None
        for k, v in player["Equipped"].items()
    }

    player["Equipped"] = equipped
    return player
