from pyfiglet import Figlet
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live
from rich.console import Console
from rich.text import Text
import threading
import time
from gameplay_messages import show_rat, show_spider, show_bat, show_lizard, show_wolf, show_goblin, show_ogre, show_skeleton, show_troll, show_zombie, show_assassin, show_bandit, show_barbarian, show_knight, show_sorcerer, show_frank, show_gargoyle, show_lycan, show_minotaur, show_vampire, show_demon, show_drake, show_golem, show_griffin, show_mummy, show_red_dragon, show_shrek, show_sponge, show_kitty, show_homer


layout = Layout()
console = Console()
# from rich.text import Text
figlet = Figlet(font='standard') 
layout.split_column(
    Layout(name="top", ratio=2),
    Layout(name="bottom"),
)

images = [
    show_rat, show_spider, show_bat, show_lizard, show_wolf, show_goblin,
    show_ogre, show_skeleton, show_troll, show_zombie, show_assassin,
    show_bandit, show_barbarian, show_knight, show_sorcerer, show_frank,
    show_gargoyle, show_lycan, show_minotaur, show_vampire, show_demon,
    show_drake, show_golem, show_griffin, show_mummy, show_red_dragon,
    show_shrek, show_sponge, show_kitty, show_homer
]


gameplay_log = []

def add_gameplay_message(message, layout):  
    gameplay_log.append(message)
    if len(gameplay_log) > 10:
        gameplay_log.pop(0)
    text_block = "\n".join(gameplay_log)
    return layout["bottom"].update(Panel(text_block, title="Credits", border_style="green"))


def set_gameplay_message(message, layout):
    gameplay_log.clear()
    gameplay_log.append(message)
    layout["bottom"].update(Panel(message, title="Credits", border_style="green"))


def slow_print_combined(layout, delay=0.05):
    big_text = "Congratulations"
    ascii_art = figlet.renderText(big_text)
    message = "Hero! You have defeated all the monsters!"
    displayed_text = ""
    
    for char in message:
        displayed_text += char
        combined_text = ascii_art + "\n" + displayed_text  # Combine both parts
        layout["bottom"].update(
            Panel(Text(combined_text, style="bold yellow"), title="Credits", border_style="green")
        )
        time.sleep(delay)

def end_credits():
    with Live(layout, refresh_per_second=10):
        typing_thread = threading.Thread(target=slow_print_combined, args=(layout,))
        typing_thread.start()

        for image in images:
            layout["top"].update(image())
            time.sleep(2)

        typing_thread.join()
