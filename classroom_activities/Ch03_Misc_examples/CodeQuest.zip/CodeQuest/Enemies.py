import random as rand
from gameplay_messages import set_gameplay_message, add_gameplay_message
from ui import render_stats



class Enemy:
    def __init__(self, tier, name, HP, ATK, hit_chance, exp):
        self.tier = tier
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.hit_chance = hit_chance
        self.exp = exp


class Mimic(Enemy):
    def __init__(self, tier = "Chest", name = "Mimic", HP = 30, ATK = 12, hit_chance = .95, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)
        
##TIER 1 ENEMIES##
class Lizard(Enemy):
    def __init__(self, tier = "1", name = "Lizard", HP = 15, ATK = 8, hit_chance = .95, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Spider(Enemy):
    def __init__(self, tier = "1", name = "Spider", HP = 20, ATK = 10, hit_chance = .9, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Bat(Enemy):
    def __init__(self, tier = "1", name = "Bat", HP = 15, ATK = 8, hit_chance = .95, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Wolf(Enemy):
    def __init__(self, tier = "1", name = "Wolf", HP = 25, ATK = 11, hit_chance = .9, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class GiantRat(Enemy):
    def __init__(self, tier = "1", name = "Giant Rat", HP = 15, ATK = 7, hit_chance = .95, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class GiantScorpion(Enemy):
    def __init__(self, tier = "miniboss", name = "Giant Scorpion", HP = 35, ATK = 14, hit_chance = 0.85, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Sponge(Enemy):
    def __init__(self, tier = "boss", name = "Sponge Boss", HP = 50, ATK = 15, hit_chance = .8, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierOneEnemies = [Lizard, Spider, Bat, Wolf, GiantRat, Sponge, GiantScorpion]

##TIER 2 ENEMIES##
class Ogre(Enemy):
    def __init__(self, tier = "2", name = "Ogre", HP = 35, ATK = 16, hit_chance = .85, exp = 60):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Zombie(Enemy):
    def __init__(self, tier = "2", name = "Zombie", HP = 25, ATK = 13, hit_chance = .9, exp = 45):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Skeleton(Enemy):
    def __init__(self, tier = "2", name = "Skeleton", HP = 30, ATK = 12, hit_chance = .9, exp = 55):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Goblin(Enemy):
    def __init__(self, tier = "2", name = "Goblin", HP = 25, ATK = 10, hit_chance = .95, exp = 50):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Troll(Enemy):
    def __init__(self, tier = "2", name = "Troll", HP = 40, ATK = 13, hit_chance = .8, exp = 75):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Tink(Enemy):
    def __init__(self, tier = "miniboss", name = "Tink the Fairy Queen", HP = 60, ATK = 18, hit_chance = 0.9, exp = 100):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Kitty(Enemy):
    def __init__(self, tier = "boss", name = "Boss Kitty", HP = 75, ATK = 20, hit_chance = .8, exp = 125):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierTwoEnemies = [Ogre, Zombie, Skeleton, Goblin, Troll, Kitty, Tink]

##TIER 3 ENEMIES##
class Bandit(Enemy):
    def __init__(self, tier = "3", name =  "Bandit", HP = 90, ATK = 20, hit_chance = .85, exp = 100):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class DarkKnight(Enemy):
    def __init__(self, tier = "3", name = "Dark Knight", HP = 120, ATK = 25, hit_chance = .8, exp = 140):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Barbarian(Enemy):
    def __init__(self, tier = "3", name = "Barbarian", HP = 135, ATK = 20, hit_chance = .85, exp = 110):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Sorcerer(Enemy):
    def __init__(self, tier = "3", name = "Sorcerer", HP = 80, ATK = 20, hit_chance = .8, exp = 130):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Assassin(Enemy):
    def __init__(self, tier = "3", name = "Assassin", HP = 100, ATK = 17, hit_chance = .9, exp = 120):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class CursedDoll(Enemy):
    def __init__(self, tier = "miniboss", name = "Cursed Doll", HP = 100, ATK = 28, hit_chance = 0.9, exp = 150):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Homer(Enemy):
    def __init__(self, tier = "boss", name = "Boss Homer", HP = 100, ATK = 25, hit_chance = .8, exp = 175):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierThreeEnemies = [Bandit, DarkKnight, Barbarian, Sorcerer, Assassin, Homer, CursedDoll]

##TIER 4 ENEMIES##
class Frank(Enemy):
    def __init__(self, tier = "4", name = "Frank", HP = 200, ATK = 35, hit_chance = .8, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Minotaur(Enemy):
    def __init__(self, tier = "4", name = "Minotaur", HP = 300, ATK = 30, hit_chance = .85, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Gargoyle(Enemy):
    def __init__(self, tier = "4", name = "Gargoyle", HP = 225, ATK = 40, hit_chance = .7, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Vampire(Enemy):
    def __init__(self, tier = "4", name = "Vampire", HP = 250, ATK = 35, hit_chance = .8, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Lycan(Enemy):
    def __init__(self, tier = "4", name = "Lycan", HP = 270, ATK = 50, hit_chance = .65, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class MrClean(Enemy):
    def __init__(self, tier = "miniboss", name = "Mr. Clean (Unleashed)", HP = 240, ATK = 50, hit_chance = 0.95, exp = 250):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class RedDragon(Enemy): 
    def __init__(self, tier = "boss", name = "Red Dragon", HP = 300, ATK = 30, hit_chance = .8, exp = 300):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierFourEnemies = [Frank, Minotaur, Gargoyle, Vampire, Lycan, RedDragon, MrClean]

##TIER 5 ENEMIES##
class Drake(Enemy):
    def __init__(self, tier = "5", name = "Drake", HP = 400, ATK = 60, hit_chance = .7, exp = 250):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Golem(Enemy):
    def __init__(self, tier = "5", name = "Golem", HP = 450, ATK = 35, hit_chance = .65, exp = 225):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Demon(Enemy):
    def __init__(self, tier = "5", name = "Demon", HP = 375, ATK = 70, hit_chance = .7, exp = 250):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Griffin(Enemy):
    def __init__(self, tier = "5", name = "Griffin", HP = 425, ATK = 55, hit_chance = 1, exp = 275):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Mummy(Enemy):
    def __init__(self, tier = "5", name = "Mummy", HP = 500, ATK = 30, hit_chance = .9, exp = 225):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Hydra(Enemy):
    def __init__(self, tier = "miniboss", name = "Hydra", HP = 475, ATK = 60, hit_chance = 0.85, exp = 300):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Shrek(Enemy): 
    def __init__(self, tier = "boss", name = "Big Boss Shrek", HP = 500, ATK = 35, hit_chance = .8, exp = 350):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierFiveEnemies = [Drake, Golem, Demon, Griffin, Mummy, Shrek, Hydra]


def getEnemies(tier):
    if tier == 1:
        return tierOneEnemies
    elif tier == 2:
        return tierTwoEnemies
    elif tier == 3:
        return tierThreeEnemies
    elif tier == 4:
        return tierFourEnemies
    elif tier == 5:
        return tierFiveEnemies
        

def attack(enemy, player, layout):
    damageDone = enemy.ATK - player["AC"]
    if damageDone < 0:
        damageDone = 0
    if enemy.hit_chance >= rand.random():
        add_gameplay_message(enemy.name + " attacks " + player["Name"] + " for " + str(damageDone) + " damage.", layout)
        player["HP"] -= damageDone
        add_gameplay_message(player["Name"] + " has " + str(player["HP"]) + " HP remaining.", layout)
    else:
        add_gameplay_message(enemy.name + " missed!", layout)
    return layout["top_right"].update(render_stats(player))


def die(player, enemy, layout):
    set_gameplay_message(enemy.name + " has died.\n" + f"{player['Name']} has received {enemy.exp} experience points", layout) 
