from gameplay_messages import show_sword
from ui import render_stats

## Weapons
class weapon:
    def __init__(self, type, name, damage, value, equipped):
        self.type = type
        self.name = name
        self.damage = damage
        self.value = value
        self.equipped = equipped


#SWORDS#

#Rusty Sword
class rustySword(weapon):
    def __init__(self, type="Warrior", name="Rusty Sword", damage=4, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"

#Iron Sword
class ironSword(weapon):
    def __init__(self, type="Warrior", name="Iron Sword", damage=12, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Steel Sword
class steelSword(weapon):
    def __init__(self, type="Warrior", name="Steel Sword", damage=25, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Platinum Sword
class platinumSword(weapon):
    def __init__(self, type="Warrior", name="Platinum Sword", damage=40, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"


##STAFFS##

#Wooden Staff
class woodenStaff(weapon):
    def __init__ (self, type="Mage", name="Wooden Staff", damage=6, value=10, equipped=False, manaCost = 5):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Amethyst Staff
class amethystStaff(weapon):
    def __init__ (self, type="Mage", name="Amethyst Staff", damage=12, value=10, equipped=False, manaCost = 5):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Ruby Staff
class rubyStaff(weapon):
    def __init__ (self, type="Mage", name="Ruby Staff", damage=20, value=10, equipped=False, manaCost = 7):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Diamond Staff
class diamondStaff(weapon):
    def __init__ (self, type="Mage", name="Diamond Staff", damage=35, value=10, equipped=False, manaCost = 10):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#DAGGERS#

#Rusty Dagger
class boneDagger(weapon):
    def __init__(self, type="Rogue", name="Bone Dagger", damage=2, value=10, equipped=False, maxHit=3):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Iron Dagger
class ironDagger(weapon):
    def __init__(self, type="Rogue", name="Iron Dagger", damage=4, value=10, equipped=False, maxHit=4):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Obsidian Dagger
class obsidianDagger(weapon):
    def __init__(self, type="Rogue", name="Obsidian Dagger", damage=7, value=10, equipped=False, maxHit=5):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Dragonglass Dagger
class dragonglassDagger(weapon):
    def __init__(self, type="Rogue", name="Dragonglass Dagger", damage=16, value=10, equipped=False, maxHit=6):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    


##Armor
class armor:
    def __init__(self, type, name, armor, value, equipped):
        self.type = type
        self.name = name
        self.armor = armor
        self.value = value
        self.equipped = equipped


#LEATHER#

#Leather Cap
class leatherCap(armor):
    def __init__(self, type="Helmet", name="Leather Cap", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Cuirass
class leatherCuirass(armor):
    def __init__(self, type="Chest", name="Leather Vest", armor=3, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Gloves
class leatherGloves(armor):
    def __init__(self, type="Gloves", name="Leather Gloves", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"

#Leather Pants
class leatherPants(armor):
    def __init__(self, type="Legs", name="Leather Pants", armor=2, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Boots
class leatherBoots(armor):
    def __init__(self, type="Boots", name="Leather Boots", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    

#IRON#

#Iron Helmet
class ironHelmet(armor):
    def __init__(self, type="Helmet", name="Iron Helmet", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Chestplate
class ironChestplate(armor):
    def __init__(self, type="Chest", name="Iron Chestplate", armor=8, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Gauntlets
class ironGauntlets(armor):
    def __init__(self, type="Gloves", name="Iron Gauntlets", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Greaves
class ironGreaves(armor):
    def __init__(self, type="Legs", name="Iron Greaves", armor=7, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Boots
class ironBoots(armor):
    def __init__(self, type="Boots", name="Iron Boots", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    

#PLATINUM#

#Platinum gear
class platinumHelmet(armor):
    def __init__(self, type="Helmet", name="Platinum Helmet", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Chestplate
class platinumChestplate(armor):
    def __init__(self, type="Chest", name="Platinum Chestplate", armor=15, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Gauntlets
class platinumGauntlets(armor):
    def __init__(self, type="Gloves", name="Platinum Gauntlets", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Greaves
class platinumGreaves(armor):
    def __init__(self, type="Legs", name="Platinum Greaves", armor=13, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Boots
class platinumBoots(armor):
    def __init__(self, type="Boots", name="Platinum Boots", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"


##POTIONS##
class potion:
    def __init__(self, type, name, effect, value, amount, equipped):
        self.type = type
        self.name = name
        self.effect = effect
        self.value = value
        self.amount = amount
        self.equipped = equipped


#Health Potion

class healthPotion(potion):
    def __init__(self, type = "health", name="Health Potion", effect="Restores 20 HP", value=10, amount=0, equipped=False, healAmount=20):
        super().__init__(type, name, effect, value, amount, equipped)
        self.healAmount = healAmount
    def __str__(self):
        return f"{self.name} (Effect: {self.effect}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity


#Mana Potion

class manaPotion(potion):
    def __init__(self, type = "mana", name="Mana Potion", effect="Restores 20 MP", value=10, amount=0, equipped=False, manaAmount=20):
        super().__init__(type, name, effect, value, amount, equipped)
        self.manaAmount = manaAmount
    def __str__(self):
        return f"{self.name} (Effect: {self.effect}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity

#Use potion function
def usePotion(player, item, inventory, layout):
    # Check if the item is usable
    from gameplay_messages import set_gameplay_message
    if player["HP"] == player["maxHP"] and item.type == "health":
        set_gameplay_message(f"{player.name} is already at max HP!", layout)
        return
    if player["HP"] == player["maxHP"] and item.type == "mana":
        set_gameplay_message(f"{player.name} is already at max MP!", layout)
        return
    # Use item 
    set_gameplay_message(f"{item.name} used!", layout)
    if item.type == "health":
        player["HP"] += item.healAmount
        if player["HP"] >= player["maxHP"]:
            player["HP"] = player["maxHP"]
        set_gameplay_message(f"{player['Name']} now has {player['HP']} HP!", layout)
    elif item.type == "mana":
        player["MP"] += item.manaAmount
        if player["MP"] > player["maxMP"]:
            player["MP"] = player["maxMP"]
        set_gameplay_message(f"{player['Name']} now has {player['MP']} MP!", layout)
    inventory[item.name]["quantity"] -= 1
    if inventory[item.name]["quantity"] <= 0:
        del inventory[item.name]
    layout["top_right"].update(render_stats(player))


def store(layout):
    layout["top_left"].update(show_sword())
            ## need ascii art to display storefront and item types
            ## select item type to change pages and list available items
            ## select item and add to inventory and subtract gold


tierOneLootPool = [leatherCap(), leatherCuirass(), leatherGloves(), leatherPants(), leatherBoots(), rustySword(), boneDagger(), woodenStaff()]
tierTwoLootPool = [leatherCap(), leatherCuirass(), leatherGloves(), leatherPants(), leatherBoots(), ironSword(), ironDagger(), amethystStaff()]
tierThreeLootPool = [ironHelmet(), ironChestplate(), ironGauntlets(), ironGreaves(), ironBoots(), steelSword(), obsidianDagger(), rubyStaff()]
tierFourLootPool = [ironHelmet(), ironChestplate(), ironGauntlets(), ironGreaves(), ironBoots(), platinumSword(), dragonglassDagger(), diamondStaff()]
tierFiveLootPool = [platinumHelmet(), platinumChestplate(), platinumGauntlets(), platinumGreaves(), platinumBoots(), platinumSword(), dragonglassDagger(), diamondStaff()]


item_registry = {
    "Rusty Sword": rustySword,
    "Iron Sword": ironSword,
    "Steel Sword": steelSword,
    "Platinum Sword": platinumSword,
    "Wooden Staff": woodenStaff,
    "Amethyst Staff": amethystStaff,
    "Ruby Staff": rubyStaff,
    "Diamond Staff": diamondStaff,
    "Bone Dagger": boneDagger,
    "Iron Dagger": ironDagger,
    "Obsidian Dagger": obsidianDagger,
    "Dragonglass Dagger": dragonglassDagger,
    "Leather Cap": leatherCap,
    "Leather Vest": leatherCuirass,
    "Leather Gloves": leatherGloves,
    "Leather Pants": leatherPants,
    "Leather Boots": leatherBoots,
    "Iron Helmet": ironHelmet,
    "Iron Chestplate": ironChestplate,
    "Iron Gauntlets": ironGauntlets,
    "Iron Greaves": ironGreaves,
    "Iron Boots": ironBoots,
    "Platinum Helmet": platinumHelmet,
    "Platinum Chestplate": platinumChestplate,
    "Platinum Gauntlets": platinumGauntlets,
    "Platinum Greaves": platinumGreaves,
    "Platinum Boots": platinumBoots,
    "Health Potion": healthPotion,
    "Mana Potion": manaPotion
}
