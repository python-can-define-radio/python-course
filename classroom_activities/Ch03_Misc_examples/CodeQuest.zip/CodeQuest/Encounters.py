import random
import BattleLoop
import Enemies
from gameplay_messages import set_gameplay_message, add_gameplay_message, show_rat, show_spider, show_bat, show_lizard, show_wolf, show_goblin, show_ogre, show_skeleton, show_troll, show_zombie, show_assassin, show_bandit, show_barbarian, show_knight, show_sorcerer, show_frank, show_gargoyle, show_lycan, show_minotaur, show_vampire, show_demon, show_drake, show_golem, show_griffin, show_mummy, show_TBD, show_red_dragon, show_shrek, show_sponge, show_kitty, show_homer, show_doll, show_tink, show_scorpion, show_cleaner, show_hydra, show_chest_closed_tier1, show_chest_closed_tier2, show_chest_closed_tier4, show_chest_open, show_mimic_chest, show_fountain, show_table
import Items
from save_game import save_player
from ui import render_stats, render_inventory, render_equipment



def firstEncounter(player, console, layout, inventory):
    endOfRoom(player, inventory, layout)
    layout["top_left"].update(show_rat())
    valid = False
    result = None
    set_gameplay_message("You enter the dungeon and see a Giant Rat!.", layout)
    add_gameplay_message("What would you like to do?", layout)
    add_gameplay_message("1.Enter Combat\n2.Run", layout)
    while valid == False:
            decision = input()
            if decision == "1":
                enemy = Enemies.GiantRat()
                result = BattleLoop.battleLoop(player, enemy, layout, inventory)
                valid = True
            elif decision == "2":
                add_gameplay_message("Foolish mortal, you cannot escape the dungeon.", layout)
    if result == "victory":
        enemy = None
        endOfRoom(player, inventory, layout)


def reward(player, layout, tiermultiplier):
    gold = random.randint(20, 100) * tiermultiplier
    playerMultiplier = player["LUK"] * 1.1
    gold = round(gold * playerMultiplier)
    player["Gold"] += gold
    add_gameplay_message(f"You find {gold} gold.", layout)
    layout["top_right"].update(render_stats(player))


def add_item(inventory, item, quantity=1):
    if item.name in inventory:
        inventory[item.name]["quantity"] += quantity
    else:
        inventory[item.name] = {
            "item": item,
            "quantity": quantity,
        }


def enemyRoom(player, inventory, layout):
    enemyList = Enemies.getEnemies(int(player["Current Tier"]))
    enemies = list(filter(lambda e: e().tier == str(player["Current Tier"]), enemyList))
    randomEnemyClass = random.choice(enemies)
    randomEnemy = randomEnemyClass()
    if randomEnemy.name == "Spider":
        layout["top_left"].update(show_spider())
    elif randomEnemy.name == "Bat":
        layout["top_left"].update(show_bat())
    elif randomEnemy.name == "Giant Rat":
        layout["top_left"].update(show_rat())
    elif randomEnemy.name == "Lizard":
        layout["top_left"].update(show_lizard())
    elif randomEnemy.name == "Wolf":
        layout["top_left"].update(show_wolf())
    elif randomEnemy.name == "Goblin":
        layout["top_left"].update(show_goblin())
    elif randomEnemy.name == "Ogre":
        layout["top_left"].update(show_ogre())
    elif randomEnemy.name == "Skeleton":
        layout["top_left"].update(show_skeleton())
    elif randomEnemy.name == "Troll":
        layout["top_left"].update(show_troll())
    elif randomEnemy.name == "Zombie":
        layout["top_left"].update(show_zombie())
    elif randomEnemy.name == "Assassin":
        layout["top_left"].update(show_assassin())
    elif randomEnemy.name == "Bandit":
        layout["top_left"].update(show_bandit())
    elif randomEnemy.name == "Barbarian":
        layout["top_left"].update(show_barbarian())
    elif randomEnemy.name == "Dark Knight":
        layout["top_left"].update(show_knight())
    elif randomEnemy.name == "Sorcerer":
        layout["top_left"].update(show_sorcerer())
    elif randomEnemy.name == "Frank":
        layout["top_left"].update(show_frank())
    elif randomEnemy.name == "Gargoyle":
        layout["top_left"].update(show_gargoyle())
    elif randomEnemy.name == "Lycan":
        layout["top_left"].update(show_lycan())
    elif randomEnemy.name == "Minotaur":
        layout["top_left"].update(show_minotaur())
    elif randomEnemy.name == "Vampire":
        layout["top_left"].update(show_vampire())
    elif randomEnemy.name == "Demon":
        layout["top_left"].update(show_demon())
    elif randomEnemy.name == "Drake":
        layout["top_left"].update(show_drake())
    elif randomEnemy.name == "Golem":
        layout["top_left"].update(show_golem())
    elif randomEnemy.name == "Griffin":
        layout["top_left"].update(show_griffin())
    elif randomEnemy.name == "Mummy":
        layout["top_left"].update(show_mummy())
    else:
        layout["top_left"].update(show_TBD())
    set_gameplay_message(f"You enter a room and see a {randomEnemy.name}.", layout)
    add_gameplay_message("It's coming right for you!", layout)
    add_gameplay_message("Press enter to continue...", layout)
    input()
    result = BattleLoop.battleLoop(player, randomEnemy, layout, inventory)
    if result == "victory":
        reward(player, layout, int(player["Current Tier"]))
        endOfRoom(player, inventory, layout)


def bossRoom(player, inventory, layout):
    bosslist = Enemies.getEnemies(int(player["Current Tier"]))
    enemy = next((e() for e in bosslist if e().tier == "boss"))
    if enemy.name == "Boss Homer":
        layout["top_left"].update(show_homer())
    elif enemy.name == "Boss Kitty":
        layout["top_left"].update(show_kitty())
    elif enemy.name == "Red Dragon":
        layout["top_left"].update(show_red_dragon())
    elif enemy.name == "Big Boss Shrek":
        layout["top_left"].update(show_shrek())
    elif enemy.name == "Sponge Boss":
        layout["top_left"].update(show_sponge())
    else:
        layout["top_left"].update(show_TBD())
    add_gameplay_message(f"You enter a room and see {enemy.name}.", layout)
    add_gameplay_message("They are furious with you for killing their friends!", layout)
    add_gameplay_message("Press enter to continue...", layout)
    input()
    result = BattleLoop.battleLoop(player, enemy, layout, inventory)
    if result == "victory":
        reward(player, layout, int(player["Current Tier"]))
        bossLoot(player, inventory, layout)
        endOfRoom(player, inventory, layout)


def miniBossRoom(player, inventory, layout):
    bosslist = Enemies.getEnemies(int(player["Current Tier"]))
    enemy = next((e() for e in bosslist if e().tier == "miniboss"))
    if enemy.name == "Giant Scorpion":
        layout["top_left"].update(show_scorpion())
    elif enemy.name == "Tink the Fairy Queen":
        layout["top_left"].update(show_tink())
    elif enemy.name == "Cursed Doll":
        layout["top_left"].update(show_doll())
    elif enemy.name == "Mr. Clean (Unleashed)":
        layout["top_left"].update(show_cleaner())
    elif enemy.name == "Hydra":
        layout["top_left"].update(show_hydra())
    else:
        layout["top_left"].update(show_TBD())
    add_gameplay_message(f"You enter a room and see {enemy.name}.", layout)
    add_gameplay_message("They lock eyes with you and scream, 'You're the reason I need therapy!'", layout)
    add_gameplay_message("Press enter to continue...", layout)
    input()
    result = BattleLoop.battleLoop(player, enemy, layout, inventory)
    if result == "victory":
        reward(player, layout, int(player["Current Tier"]))
        specialEnemyLoot(player, inventory, layout)
        endOfRoom(player, inventory, layout)


def endOfRoom(player, inventory, layout, Inspected=False):
    roomInspected = Inspected
    valid = False
    while valid == False:
        add_gameplay_message("What would you like to do?\n1. Inventory\n2. Shop\n3. Examine the room\n4. Continue\n5. Save Game", layout)
        choice = input()
        if choice == "1":
            set_gameplay_message("Inventory displayed to the right:", layout)
            layout["bottom_right"].update(render_inventory(inventory))
    

            set_gameplay_message("Select an item to use or equip by number (or 0 to cancel):", layout)
            try:
                selection = int(input())
                if selection == 0:
                    layout["bottom_right"].update(render_equipment(player))  # back to equipment view
                    continue
        
                inventory_items = list(inventory.items())
                selected_item = inventory_items[selection - 1][1]["item"]
        
    
                if isinstance(selected_item, Items.potion):
                    Items.usePotion(player, selected_item, inventory, layout)
                elif isinstance(selected_item, (Items.weapon, Items.armor)):
                    equip_item(player, selected_item, inventory, layout)
                    layout["top_right"].update(render_stats(player))
                else:
                    add_gameplay_message("That item can't be used or equipped.", layout)
            
            except (ValueError, IndexError):
                add_gameplay_message("Invalid selection.", layout)


            layout["bottom_right"].update(render_equipment(player))
        
        elif choice == "2":
            Items.store(layout)
            
        elif choice == "3":
            if roomInspected == False:
                inspectRoom(player, inventory, layout)
                add_gameplay_message("Press enter to continue...", layout)
                input()
                roomInspected = True
            else:
                set_gameplay_message("You already inspected the room.", layout)
                add_gameplay_message("Press enter to continue...", layout)
                input()
        elif choice == "4":
            set_gameplay_message("You continue on your journey.", layout)
            add_gameplay_message("Press enter to continue...", layout)
            input()
            valid = True
        elif choice == "5":
            save_player(player)
            set_gameplay_message("Game saved at this point.", layout)
            add_gameplay_message("Press enter to return...", layout)
            selection = input()
        elif choice == "":
            continue

def inspectRoom(player, inventory, layout):
    set_gameplay_message("You take a moment to look around the room to see if you can find anything useful.", layout)
    detectItem = random.randint(1, 100)
    item = None
    if detectItem <= 30:
        item = Items.healthPotion()
        add_item(inventory, item)
        set_gameplay_message(f"You found a {item.name}!", layout)
    elif 30 < detectItem <= 60:
        item = Items.manaPotion()
        add_item(inventory, item)
        set_gameplay_message(f"You found a {item.name}!", layout)
    if 60 < detectItem <= 80:
        if player["Current Tier"] == 1:
            item = random.choice(Items.tierOneLootPool)
            set_gameplay_message(f"You found a {item.name}!", layout)
            add_item(inventory, item)
        elif player["Current Tier"] == 2:
            item = random.choice(Items.tierTwoLootPool)
            set_gameplay_message(f"You found a {item.name}!", layout)
            add_item(inventory, item)
        elif player["Current Tier"] == 3:
            item = random.choice(Items.tierThreeLootPool)
            set_gameplay_message(f"You found a {item.name}!", layout)
            add_item(inventory, item)
        elif player["Current Tier"] == 4:
            item = random.choice(Items.tierFourLootPool)
            set_gameplay_message(f"You found a {item.name}!", layout)
            add_item(inventory, item)
        elif player["Current Tier"] == 5:
            item = random.choice(Items.tierFiveLootPool)
            set_gameplay_message(f"You found a {item.name}!", layout)
            add_item(inventory, item)
    elif 80 < detectItem <= 100:
        set_gameplay_message("You find nothing of interest.", layout)

##TREASURE ROOMS##
def tierOneTreasureRoom(player, roomCounter, inventory, layout):
    roomInspected = False
    layout["top_left"].update(show_chest_closed_tier1())
    set_gameplay_message("You enter a long forgotten supply cache, smashed crates and barrels are strewn about.", layout)
    add_gameplay_message("You see a wooden chest that looks intact and appears to be have a 3-digit combination.", layout)
    add_gameplay_message("Next to the chest you see some scribblings that say 'Their sum is 14 and their product is 64'", layout)
    add_gameplay_message("1. Try to open the chest\n2. Ignore it and continue.", layout)
    choice = input()
    if choice == "1":
        set_gameplay_message("Enter the three numbers. or 000 if you give up", layout)
        combo = ""
        correct = ["248", "482", "824", "284", "428", "842"]
        while combo not in correct:
            combo = input()
            if combo == "000":
                break
            if combo in correct:
                loot = random.randint(1, 100)
                potionChance = random.randint(1, 2)
                layout["top_left"].update(show_chest_open())
                if loot <= 10:
                    layout["top_left"].update(show_mimic_chest())
                    enemy = Enemies.Mimic()
                    set_gameplay_message(f"It was a trap the Mimic attacks.", layout)
                    add_gameplay_message("Press enter to continue...", layout)
                    input()
                    result = BattleLoop.battleLoop(player, enemy, layout, inventory)
                    if result == "victory":
                        reward(player, layout, int(player["Current Tier"]))
                        endOfRoom(player, inventory, layout, roomInspected)
                    elif result == "defeat":
                        roomInspected = True
                elif 10 < loot <= 60:
                    item1 = random.choice(Items.tierOneLootPool)
                    add_item(inventory, item1)
                    if potionChance == 1:
                        item2 = Items.healthPotion()
                    elif potionChance == 2:
                        item2 = Items.manaPotion()
                    quantity = random.randint(1, 2)
                    add_item(inventory, item2, quantity)
                    set_gameplay_message(f"You unlocked the chest and found a {item1.name} and a {item2.name} (Quantity: {quantity})!", layout)
                elif 60 < loot <= 100:
                    potionChance = random.randint(1, 2)
                    if potionChance == 1:
                        item1 = Items.healthPotion()
                    elif potionChance == 2:
                        item1 = Items.manaPotion()
                    quantity = random.randint(1, 2)
                    add_item(inventory, item1, quantity)
                    set_gameplay_message(f"You unlocked the chest and found a {item1.name} (Quantity: {quantity})!", layout)
            else:
                add_gameplay_message("Enter the three numbers. or 000 if you give up", layout)
        reward(player, layout, int(player["Current Tier"]))
    elif choice == "2":
        add_gameplay_message("You continue on your journey...", layout)
    endOfRoom(player, inventory, layout, roomInspected)
    return inventory, roomCounter

def tierTwoTreasureRoom(player, roomCounter, inventory, layout):
    roomInspected = False
    layout["top_left"].update(show_chest_closed_tier2())
    set_gameplay_message("You enter a modest storage room, supplies are strewn about.", layout)
    add_gameplay_message("There is a promising looking box wrapped in a chain in the corner, the padlock has a 4-letter combination.", layout)
    add_gameplay_message("A message is scrawled on the wall 'First in hell, Second in book, Third in rope, Last in eviscerate.'", layout)
    add_gameplay_message("1. Try to enter the combination.\n2. Ignore it and continue.", layout)
    choice = input()
    if choice == "1":
        set_gameplay_message("Enter the four letters. or 000 if you give up", layout)
        code = "hope"
        combo = ""
        while combo != code:
            combo = input()
            if combo == "000":
                break
            if combo == code:
                loot = random.randint(1, 100)
                potionChance = random.randint(1, 2)
                layout["top_left"].update(show_chest_open())
                if loot <= 10:
                    layout["top_left"].update(show_mimic_chest())
                    enemy = Enemies.Mimic()
                    set_gameplay_message(f"It was a trap the Mimic attacks.", layout)
                    add_gameplay_message("Press enter to continue...", layout)
                    input()
                    result = BattleLoop.battleLoop(player, enemy, layout, inventory)
                    if result == "victory":
                        reward(player, layout, int(player["Current Tier"]))
                        endOfRoom(player, inventory, layout, roomInspected)
                    elif result == "defeat":
                        roomInspected = True
                elif 10 < loot <= 60:
                    item1 = random.choice(Items.tierOneLootPool)
                    add_item(inventory, item1)
                    if potionChance == 1:
                        item2 = Items.healthPotion()
                    elif potionChance == 2:
                        item2 = Items.manaPotion()
                    quantity = random.randint(1, 2)
                    add_item(inventory, item2, quantity)
                    set_gameplay_message(f"You unlocked the chest and found a {item1.name} and a {item2.name} (Quantity: {quantity})!", layout)
                elif 60 < loot <= 100:
                    potionChance = random.randint(1, 2)
                    if potionChance == 1:
                        item1 = Items.healthPotion()
                    elif potionChance == 2:
                        item1 = Items.manaPotion()
                    quantity = random.randint(1, 2)
                    add_item(inventory, item1, quantity)
                    set_gameplay_message(f"You unlocked the chest and found a {item1.name} (Quantity: {quantity})!", layout)
            else:
                add_gameplay_message("Enter the three numbers. or 000 if you give up", layout)
        reward(player, layout, int(player["Current Tier"]))
    elif choice == "2":
        add_gameplay_message("You continue on your journey...", layout)
    endOfRoom(player, inventory, layout, roomInspected)
    return inventory, roomCounter

def tierThreeTreasureRoom(player, roomCounter, inventory, layout):
    layout["top_left"].update(show_chest_closed_tier4())
    roomInspected = False
    ## need ascii art and riddle for three-five
    set_gameplay_message("You find yourself in a brightly lit armory, assorted weapon racks and armor stands line the walls.", layout)
    add_gameplay_message("A particular shelf of supplies sticks out to you.", layout)
    add_gameplay_message("1. Inspect the shelf\n2. Ignore it and continue.", layout)
    choice = input()
    if choice == "1":
        loot = random.randint(1, 100)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierThreeLootPool)
            add_item(inventory, item1)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(2, 4)
            add_item(inventory, item2, quantity)
            add_gameplay_message(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!", layout)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(2, 4)
            add_item(inventory, item1, quantity)
            add_gameplay_message(f"You found a {item1.name} (Quantity: {quantity})!", layout)
        reward(player, layout, int(player["Current Tier"]))
    elif choice == "2":
        add_gameplay_message("You continue on your journey...", layout)
    endOfRoom(player, inventory, layout)
    return inventory, roomCounter

def tierFourTreasureRoom(player, roomCounter, inventory, layout):
    layout["top_left"].update(show_chest_closed_tier4())
    roomInspected = False
    set_gameplay_message("You enter a lavishly decorated room, torches line the walls and a large chandelier hangs from the ceiling.", layout)
    add_gameplay_message("A large ornate chest sits in the center.", layout)
    add_gameplay_message("1. Open the Chest\n2. Ignore it and continue.", layout)
    choice = input()
    if choice == "1":
        loot = random.randint(1, 100)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierFourLootPool)
            add_item(inventory, item1)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(2, 5)
            add_item(inventory, item2, quantity)
            add_gameplay_message(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!", layout)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(2, 5)
            add_item(inventory, item1, quantity)
            add_gameplay_message(f"You found a {item1.name} (Quantity: {quantity})!", layout)
        reward(player, layout, int(player["Current Tier"]))
    elif choice == "2":
        add_gameplay_message("You continue on your journey...", layout)
    endOfRoom(player, inventory, layout)
    return inventory, roomCounter

def tierFiveTreasureRoom(player, roomCounter, inventory, layout):
    layout["top_left"].update(show_table())
    roomInspected = False
    set_gameplay_message("You enter a stark, immaculate room, the walls lined with gleaming weapons of war.", layout)
    add_gameplay_message("A black marble table in the center looks to have some supplies on it.", layout)
    add_gameplay_message("1. Approach the table\n2. Ignore it and continue.", layout)
    choice = input()
    if choice == "1":
        loot = random.randint(1, 100)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierFiveLootPool)
            add_item(inventory, item1)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(4, 6)
            add_item(inventory, item2, quantity)
            add_gameplay_message(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!", layout)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(4, 6)
            add_item(inventory, item1, quantity)
            add_gameplay_message(f"You found a {item1.name} (Quantity: {quantity})!", layout)
        reward(player, layout, int(player["Current Tier"]))
    elif choice == "2":
        add_gameplay_message("You continue on your journey...", layout)
    endOfRoom(player, inventory, layout)
    return inventory, roomCounter

def treasureRoomSelector(player, roomCounter, inventory, layout):
    if player["Current Tier"] == 1:
        inventory, roomCounter = tierOneTreasureRoom(player, roomCounter, inventory, layout)
    elif player["Current Tier"] == 2:
        inventory, roomCounter = tierTwoTreasureRoom(player, roomCounter, inventory, layout)
    elif player["Current Tier"] == 3:
        inventory, roomCounter = tierThreeTreasureRoom(player, roomCounter, inventory, layout)
    elif player["Current Tier"] == 4:
        inventory, roomCounter = tierFourTreasureRoom(player, roomCounter, inventory, layout)
    elif player["Current Tier"] == 5:
        inventory, roomCounter = tierFiveTreasureRoom(player, roomCounter, inventory, layout)

##SPECIAL ROOMS##
def restRoom(player, inventory, layout):
    layout["top_left"].update(show_fountain())
    set_gameplay_message("You enter a tranquil room with a fountain in the center, you think you see something shiny at the bottom of the fountain.\nSelect wisely you may only choose once.", layout)
    add_gameplay_message("1. Drink from the fountain.\n2. Dive in and rummage around.", layout)
    choice = input()
    if choice == "1":
        add_gameplay_message("You feel rejuvenated and refreshed.", layout)
        player["HP"] = player["maxHP"]
        player["MP"] = player["maxMP"]
        layout["top_right"].update(render_stats(player))
    elif choice == "2":
        bonus = None
        chance = random.randint(1, 10)
        if 0 < chance <=9:
            if player["Current Tier"] == 1:
                loot = random.choice(Items.tierTwoLootPool)
            elif player["Current Tier"] == 2:
                loot = random.choice(Items.tierThreeLootPool)
            elif player["Current Tier"] == 3:
                loot = random.choice(Items.tierFourLootPool)
            elif player["Current Tier"] == 4:
                loot = random.choice(Items.tierFiveLootPool)
            elif player["Current Tier"] == 5:
                loot = random.choice(Items.tierFiveLootPool)
                bonus = random.choice(Items.tierFiveLootPool)
            add_gameplay_message(f"Wedged in the bottom of the fountain you found a {loot.name}", layout)
            add_item(inventory, loot)
            if bonus:
                add_gameplay_message(f"Wow, when you pulled out the {loot.name} you also seem to have dislodged a {bonus.name}.", layout)
                add_item(inventory, bonus)
        else:
            if player["Current Tier"] == 1:
                loot = random.sample(Items.tierThreeLootPool, k=1)
            elif player["Current Tier"] == 2:
                loot = random.sample(Items.tierFourLootPool, k=1)
            elif player["Current Tier"] == 3:
                loot = random.sample(Items.tierFiveLootPool, k=1)
            elif player["Current Tier"] == 4:
                loot = random.sample(Items.tierFiveLootPool, k=2)
            elif player["Current Tier"] == 5:
                loot = random.sample(Items.tierFiveLootPool, k=3)
            add_gameplay_message(f"Wedged in the bottom of the fountain you found a {loot[0].name}", layout)
            add_item(inventory, loot[0])
            if len(loot)>=2:
                add_gameplay_message(f"Wow, when you pulled out the {loot[0].name} you also seem to have dislodged a {loot[1].name}.", layout)
                add_item(inventory, loot[1])
            if len(loot)==3:
                add_gameplay_message(f"Ridiculous, when you pulled out the {loot[1].name} stuck to it was a {loot[2].name}", layout)
                add_item(inventory, loot[2])
    add_gameplay_message("Press enter to continue...", layout)
    input()
    endOfRoom(player, inventory, layout)

def specialEnemyLoot(player, inventory, layout):
    if player["Current Tier"] == 1:
        LootPool = Items.tierOneLootPool
    elif player["Current Tier"] == 2:
        LootPool = Items.tierTwoLootPool
    elif player["Current Tier"] == 3:
        LootPool = Items.tierThreeLootPool
    elif player["Current Tier"] == 4:
        LootPool = Items.tierFourLootPool
    elif player["Current Tier"] == 5:
        LootPool = Items.tierFiveLootPool 
    lootoptions = random.sample(LootPool, k=3)
    i = 1
    add_gameplay_message("Choose an item by number: ", layout)
    for item in lootoptions:
        add_gameplay_message(f"{i}. {lootoptions[i-1].name}", layout)
        i += 1     
    while True:
        try:
            choice = int(input())
            if 1 <= choice <= len(lootoptions):
                break
            else:
                add_gameplay_message(f"Please enter a number between 1 and {len(lootoptions)}.", layout)
        except ValueError:
            add_gameplay_message("Invalid input. Please enter a number.", layout)
    set_gameplay_message(f"You have acquired {lootoptions[choice-1].name}!", layout)
    add_item(inventory, lootoptions[choice-1])


def bossLoot(player, inventory, layout):
    if player["Current Tier"] == 1:
        LootPool = Items.tierOneLootPool
    elif player["Current Tier"] == 2:
        LootPool = Items.tierTwoLootPool
    elif player["Current Tier"] == 3:
        LootPool = Items.tierThreeLootPool
    elif player["Current Tier"] == 4:
        LootPool = Items.tierFourLootPool
    elif player["Current Tier"] == 5:
        LootPool = Items.tierFiveLootPool 
    lootoptions = random.sample(LootPool, k=5)
    i = 1
    add_gameplay_message("Choose an item by number: ", layout)
    for item in lootoptions:
        add_gameplay_message(f"{i}. {lootoptions[i-1].name}", layout)
        i += 1     
    while True:
        try:
            choice = int(input())
            if 1 <= choice <= len(lootoptions):
                break
            else:
                add_gameplay_message(f"Please enter a number between 1 and {len(lootoptions)}.", layout)
        except ValueError:
            add_gameplay_message("Invalid input. Please enter a number.", layout)
    set_gameplay_message(f"You have acquired {lootoptions[choice-1].name}!", layout)
    add_item(inventory, lootoptions[choice-1])
    endOfRoom(player, inventory, layout)


def equip_item(player, selected_item, inventory, layout):
    """
    Equip a weapon or armor item for the player. Weapons are restricted by class. Armor is equipped by slot.
    Updates the inventory to remove equipped items.
    """
    item_name = selected_item.name

    if isinstance(selected_item, Items.weapon):
        if player["Class"] != selected_item.type:
            add_gameplay_message(f"{player['Name']} cannot equip {item_name} (for {selected_item.type}s).", layout)
            return False
        current_weapon = player["Equipped"].get("Weapon")
        if current_weapon:
            current_weapon.equipped = False
            add_item(inventory, current_weapon)

        player["Equipped"]["Weapon"] = selected_item
        selected_item.equipped = True
    elif isinstance(selected_item, Items.armor):
        slot = selected_item.type  
        current_armor = player["Equipped"].get(slot)
        if current_armor:
            current_armor.equipped = False
            add_item(inventory, current_armor)

        player["Equipped"][slot] = selected_item
        selected_item.equipped = True
    else:
        add_gameplay_message(f"{item_name} cannot be equipped.", layout)
        return False

    if item_name in inventory:
        if inventory[item_name]["quantity"] > 1:
            inventory[item_name]["quantity"] -= 1
        else:
            del inventory[item_name]

    add_gameplay_message(f"{player['Name']} equipped {item_name}.", layout)
    player["AC"] = 0
    for slot, item in player["Equipped"].items():
        if slot != "Weapon" and item is not None:
            player["AC"] += item.armor
    return True

def gameplayLoop(player, roomCounter, inventory, console, layout):
    roomSelector = 0
    treasureRoomVistited = False
    restRoomVisited = False
    while player["HP"] > 0 and roomCounter <= 10:
        if roomCounter == 0 and player["Current Tier"] == 1:
            firstEncounter(player, console, layout, inventory)
            roomCounter += 1
            continue
        else:
            roomCounter = 1 
            endOfRoom(player, inventory, layout)
        if 1 <= roomCounter < 5:
            roomSelector = random.randint(1, 10)
            if roomSelector == 1 and treasureRoomVistited == False:
                treasureRoomSelector(player, roomCounter, inventory, layout)
                treasureRoomVistited = True
            elif 2 <= roomSelector <= 9:
                enemyRoom(player, inventory, layout)
            elif roomSelector == 10 and restRoomVisited == False:
                restRoom(player, inventory, layout)
                restRoomVisited = True
            else:
                enemyRoom(player, inventory, layout)
            roomCounter += 1
            continue
        elif roomCounter == 5:
            set_gameplay_message("AHHH A MINIBOSS WOW SO COOL..", layout)
            miniBossRoom(player, inventory, layout)
            roomCounter += 1
        elif 5 < roomCounter < 10:
            roomSelector = random.randint(1, 10)
            if roomSelector <= 2 and treasureRoomVistited == False:
                treasureRoomSelector(player, roomCounter, inventory, layout)
                treasureRoomVistited = True
            elif 2 < roomSelector <= 8:
                enemyRoom(player, inventory, layout)
            elif 8 < roomSelector <= 10 and restRoomVisited == False:
                restRoom(player, inventory, layout)
                restRoomVisited = True
            else:
                enemyRoom(player, inventory, layout)
            roomCounter += 1
            continue
        elif roomCounter == 10:
            set_gameplay_message("HOLY COW A BOSS WOW SO POWERFUL...", layout)
            bossRoom(player, inventory, layout)
            roomCounter = 1
            if player["Current Tier"] < 5:
                player["Current Tier"] += 1
                set_gameplay_message(f"Entering Tier {player['Current Tier']}", layout)
                add_gameplay_message("You find some stairs that ascend to the next level.", layout)
                add_gameplay_message("Press enter to ascend the stairs.", layout)
                input()
                treasureRoomVistited = False
                restRoomVisited = False
                continue
            else: 
                add_gameplay_message("VICTORY", layout)
                return "Victory"

