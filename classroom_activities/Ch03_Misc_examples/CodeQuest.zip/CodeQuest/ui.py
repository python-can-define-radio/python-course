from rich.console import Console
from rich.layout import Layout
from rich.panel import Panel



def make_layout():
    console = Console()
    layout = Layout()
    layout.split_row(
        Layout(name="left", size=135),
        Layout(name="right", size=30),
    )
    layout["right"].split_column(
        Layout(name="top_right", size=25),
        Layout(name="bottom_right", size=15),
    )
    layout["left"].split_column(
        Layout(name="top_left", size=25),
        Layout(name="bottom_left", size=15)
    )
    return console, layout


def render_stats(player):
    stats = "\n".join([
        f"[bold]Name:[/] {player['Name']}",
        f"[bold]Class:[/] {player['Class']}",
        f"[bold]Level:[/] {player['Level']}",
        f"[bold]HP:[/] {player['HP']}/{player['maxHP']}",
        f"[bold]MP:[/] {player['MP']}/{player['maxMP']}",
        f"[bold]AC:[/] {player['AC']}",
        f"[bold]STR:[/] {player['STR']}",
        f"[bold]DEX:[/] {player['DEX']}",
        f"[bold]INT:[/] {player['INT']}",
        f"[bold]CON:[/] {player['CON']}",
        f"[bold]LUK:[/] {player['LUK']}",
        f"[bold]Gold:[/] {player['Gold']}",
        f"[bold]EXP:[/] {player['EXP']}/{player['levelXP']}",
    ])
    return Panel(stats, title="Player Stats", border_style="cyan")


def render_equipment(player):
    equipment = player.get("Equipped", {})
    lines = []

    for slot, item in equipment.items():
        item_name = item.name if item else "None"
        lines.append(f"{slot}: {item_name}")

    text = "\n".join(lines)
    return Panel(text, title="Equipped Items", border_style="cyan")



def render_inventory(inventory):
    lines = []
    inventory_items = list(inventory.items())
    if not inventory_items:
        text_block = "Inventory is empty."
    else:
        for idx, (item_name, data) in enumerate(inventory_items):
            quantity = data["quantity"]
            lines.append(f"{idx + 1}. {item_name} x{quantity}")
        text_block = "\n".join(lines)
    return Panel(text_block, title="Inventory", border_style="yellow")
