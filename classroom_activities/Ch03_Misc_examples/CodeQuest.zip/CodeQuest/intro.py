from rich.live import Live
from rich.panel import Panel
from rich.console import Console
from rich.text import Text
from rich.layout import Layout
import sys
import time

# OS-specific imports for non-blocking keypress detection
if sys.platform.startswith("win"):
    import msvcrt
else:
    import select
    import tty
    import termios

console = Console()

intro_lines = [
    "A long time ago in a terminal far, far away...",
    "", "", "", "", "", "",
    "", "", "Episode XXXVIII",
    "THE FINAL CONFLICT", "", "", "", "", "", "",
    "", "", "It is a period of epic keyboard wars.",
    "", "", "Rebel coders, striking from hidden repos,",
    "", "", "have won their first victory against the",
    "", "", "evil Galactic Debugger.",
    "", "", "", "", "", "",
    "", "", "During the battle, Rebel developers managed",
    "", "", "to steal secret plans to the Debugger’s",
    "", "", "ultimate weapon, NORTON ANTIVIRUS,",
    "", "", "an armored vulnerability tracker with enough",
    "", "", "power to crash the entire neonet...",
    "", "", "", "", "", "",
    "", "", "Pursued by the Debugger’s sinister agents,",
    "", "", "Rebel codemancers aligned with algorithmic agents",
    "", "", "of the Order of Sys-Knights race through cyberspace,",
    "", "", "custodians of the designs that can save...",
    "", "", "or destroy... the universe.",
    "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "", "",
    "", "", "and restore freedom to the galaxy of code."
]

DELAY = 0.7
VISIBLE_HEIGHT = console.size.height - 6  # Leaves room for the "skip" panel

def enter_pressed():
    if sys.platform.startswith("win"):
        # Windows
        if msvcrt.kbhit():
            ch = msvcrt.getwch()
            if ch == '\r':  # Enter key
                return True
            # flush any other key presses
        return False
    else:
        # Linux/macOS
        dr,dw,de = select.select([sys.stdin], [], [], 0)
        if dr:
            c = sys.stdin.read(1)
            if c == '\n':  # Enter key
                return True
        return False

def run_opening_scene():
    skip_requested = False
    scroll_buffer = [""] * VISIBLE_HEIGHT

    layout = Layout()
    layout.split_column(
        Layout(name="main", ratio=10),
        Layout(name="bottom", size=3)
    )

    if not sys.platform.startswith("win"):
        # On Linux, set terminal to raw mode for non-blocking stdin reading
        fd = sys.stdin.fileno()
        old_settings = termios.tcgetattr(fd)
        tty.setcbreak(fd)

    try:
        with Live(layout, screen=True, refresh_per_second=10, console=console):
            for line in intro_lines + [""] * VISIBLE_HEIGHT:
                if enter_pressed():
                    skip_requested = True
                    break

                scroll_buffer.pop(0)
                scroll_buffer.append(line.center(console.size.width))

                styled_text = Text("\n".join(scroll_buffer), style="bold yellow")
                layout["main"].update(Panel(styled_text, border_style="bright_blue"))

                layout["bottom"].update(
                    Panel(Text.from_markup("Press [bold cyan]Enter[/bold cyan] now to skip intro...", justify="center"),
                          border_style="dim")
                )

                time.sleep(DELAY)

    finally:
        if not sys.platform.startswith("win"):
            # Restore terminal settings
            termios.tcsetattr(fd, termios.TCSADRAIN, old_settings)

    console.clear()

    if not skip_requested:
        try:
            console.print("\n" * (console.size.height // 2))
            console.print("[bold green]" + "Press Enter to begin, adventurer...".center(console.size.width) + "[/bold green]")
            input()
        except Exception:
            console.print("[red]EOFError occurred waiting for Enter.[/red]")

    return skip_requested
