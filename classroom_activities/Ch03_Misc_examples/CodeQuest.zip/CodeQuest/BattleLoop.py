import random
import sys
import Enemies as en
from gameplay_messages import set_gameplay_message, add_gameplay_message, show_corpse
import Items as it
from ui import render_stats, render_equipment, render_inventory


        
def battleLoop(player, enemy, layout, inventory):
    set_gameplay_message("What would you like to do?", layout)
    while player["HP"] > 0 or enemy.HP > 0:
        add_gameplay_message("1. Attack", layout)
        add_gameplay_message("2. Use Item", layout)
        add_gameplay_message("3. Flee", layout)
        choice = input()
        if choice == "1":
            if player["Class"] == "Warrior":
                player_attack = random.randint(2, player["Equipped"]["Weapon"].damage + player["STR"])
            elif player["Class"] == "Mage":
                player_attack = random.randint(2, player["Equipped"]["Weapon"].damage + player["INT"])
            elif player["Class"] == "Rogue":
                player_attack = random.randint(2, player["Equipped"]["Weapon"].damage + player["DEX"])
            enemy.HP -= player_attack
            add_gameplay_message(f"{player['Name']} has done {player_attack} damage to {enemy.name} they have {enemy.HP} HP remaining.", layout)
        elif choice == "2":
            set_gameplay_message("Inventory displayed to the right:", layout)
            layout["bottom_right"].update(render_inventory(inventory))
    

            set_gameplay_message("Select an item to use or equip by number (or 0 to cancel):", layout)
            try:
                selection = int(input())
                if selection == 0:
                    layout["bottom_right"].update(render_equipment(player))  # back to equipment view
                    continue
        
                inventory_items = list(inventory.items())
                selected_item = inventory_items[selection - 1][1]["item"]
        
    
                if isinstance(selected_item, it.potion):
                    it.usePotion(player, selected_item, inventory, layout)
                elif isinstance(selected_item, (it.weapon, it.armor)):
                    from Encounters import equip_item
                    equip_item(player, selected_item, inventory, layout)
                    layout["top_right"].update(render_stats(player))
                else:
                    add_gameplay_message("That item can't be used or equipped.", layout)
            
            except (ValueError, IndexError):
                add_gameplay_message("Invalid selection.", layout)


            layout["bottom_right"].update(render_equipment(player))
        elif choice == "3":
            set_gameplay_message("You flee.", layout)
            return "defeat"
        if enemy.HP > 0:
            en.attack(enemy, player, layout)
        if player["HP"] <= 0:
            layout["top_left"].update(show_corpse())
            set_gameplay_message("I'm sorry adventurer you have perished.", layout)
            add_gameplay_message("Would you like to try again y/n.", layout)
            selection = input()
            if selection == "y":
                from Main import main
                main()
            else:
                sys.exit()
        if enemy.HP <= 0:
            en.die(player, enemy, layout)
            player["EXP"] += enemy.exp
            check_level(player, layout)
            layout["top_right"].update(render_stats(player))
            return "victory"
        

def check_level(player, layout):
    while player["EXP"] >= player["levelXP"]:
        player["Level"] += 1
        player["EXP"] -= player["levelXP"]
        player["levelXP"] = player["levelXP"] * player["Level"] + 50
        set_gameplay_message(f"Congratulations you have leveled up you are now level {player['Level']}", layout)
        level_up(player, layout)
        if player["EXP"] >= player["levelXP"]:
            set_gameplay_message("Hold on we aren't done yet. You seem to have leveled up again.", layout)
            add_gameplay_message("Press enter to continue...", layout)
            input()
    return layout["top_right"].update(render_stats(player))
    

def level_up(player, layout):
    count = 2
    while count > 0:
        add_gameplay_message(f"You have {count} points to increase stats which would you like to increase",layout)
        add_gameplay_message("1: STR\n2: INT\n3: DEX\n4: CON\n5: LUK", layout)
        user_input = input().strip()

        if user_input == "":
            add_gameplay_message("No input detected. Try again.", layout)
            continue

        if not user_input.isdigit():
            add_gameplay_message("Invalid input... Did you forget to make a selection? type 1-5 to choose a stat to increase.", layout)
            continue

        statchoice = int(user_input)
        if statchoice == 1:
            player["STR"] += 1
        elif statchoice == 2:
            player["INT"] += 1
        elif statchoice == 3:
            player["DEX"] += 1
        elif statchoice == 4:
            player["CON"] += 1
            player["maxHP"] += 10
            player["HP"] = player["maxHP"]
        elif statchoice == 5:
            player["LUK"] += 1
        count -= 1
        set_gameplay_message("", layout)
        layout["top_right"].update(render_stats(player))