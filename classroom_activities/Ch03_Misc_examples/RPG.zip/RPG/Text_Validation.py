from prompt_toolkit.validation import Validator, ValidationError
from prompt_toolkit import prompt

class FunctionyValidator(Validator):
    def __init__(self, valfunc):
        self.valfunc = valfunc

    def validate(self, document):
        text = document.text
        valresult = self.valfunc(text)
        if valresult != "":
            raise ValidationError(message = valresult)
        
def isAlphaValidate(x: str) -> str:
    try:
        strx = x.isalpha()
    except:
        return "Please enter a valid response"
    
    if strx == True:
        return ""
    else:
        return "Enter a valid selection"
    
def battleLoopValidate(x: str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <=4:
        return ""
    else:
        return "Enter a valid selection"
    
def biChoiceValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 2:
        return "" 
    else:
        return "Enter a valid selection"

def levelUpValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 7:
        return ""
    else:
        return "Enter a valid selection"
    
def classValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 4:
        return ""
    else:
        return "Enter a valid selection"
    
def ynValidate(x:str) -> str:
    try:
        strx = x.isalpha()
    except:
        return "Please enter a a valid response"
    
    if x == "y" or x =="n":
        return ""
    else:
        return "Enter a valid selection"
    
def endOfRoomValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 5:
        return ""
    else:
        return "Enter a valid selection"
    
def digitValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 100:
        return ""
    else:
        return "Enter a valid selection"
    
def specialLootValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 3:
        return ""
    else:
        return "Enter a valid selection"
    
def bossLootValidate(x:str) -> str:
    try:
        numx = int(x)
    except:
        return "Please enter a number"
    
    if 0 < numx <= 5:
        return ""
    else:
        return "Enter a valid selection"