import time 
import sys

def scroll(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(.001)
    print()
    return str("")

def scrollSlow(text):
    for char in text:
        sys.stdout.write(char)
        sys.stdout.flush()
        time.sleep(.15)
    print()
    return str("")