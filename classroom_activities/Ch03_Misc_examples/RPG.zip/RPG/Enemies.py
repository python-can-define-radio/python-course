import PlayerCharacter as pc
import Items as it
import random as rand
import TextScroll as ts
class Enemy:
    def __init__(self, tier, name, HP, ATK, hit_chance, exp):
        self.tier = tier
        self.name = name
        self.HP = HP
        self.ATK = ATK
        self.hit_chance = hit_chance
        self.exp = exp


##TIER 1 ENEMIES##
class Lizard(Enemy):
    def __init__(self, tier = "1", name = "Lizard", HP = 15, ATK = 8, hit_chance = .95, exp = 10):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Spider(Enemy):
    def __init__(self, tier = "1", name = "Spider", HP = 20, ATK = 10, hit_chance = .9, exp = 15):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Bat(Enemy):
    def __init__(self, tier = "1", name = "Bat", HP = 15, ATK = 8, hit_chance = .95, exp = 5):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Wolf(Enemy):
    def __init__(self, tier = "1", name = "Wolf", HP = 25, ATK = 11, hit_chance = .9, exp = 15):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class GiantRat(Enemy):
    def __init__(self, tier = "1", name = "Giant Rat", HP = 15, ATK = 7, hit_chance = .95, exp = 8):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierOneEnemies = [Lizard, Spider, Bat, Wolf, GiantRat]

##TIER 2 ENEMIES##
class Ogre(Enemy):
    def __init__(self, tier = "2", name = "Ogre", HP = 35, ATK = 16, hit_chance = .85, exp = 60):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Zombie(Enemy):
    def __init__(self, tier = "2", name = "Zombie", HP = 25, ATK = 13, hit_chance = .9, exp = 45):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Skeleton(Enemy):
    def __init__(self, tier = "2", name = "Skeleton", HP = 30, ATK = 12, hit_chance = .9, exp = 55):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Goblin(Enemy):
    def __init__(self, tier = "2", name = "Goblin", HP = 25, ATK = 10, hit_chance = .95, exp = 50):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Troll(Enemy):
    def __init__(self, tier = "2", name = "Troll", HP = 40, ATK = 13, hit_chance = .8, exp = 75):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierTwoEnemies = [Ogre, Zombie, Skeleton, Goblin, Troll]

##TIER 3 ENEMIES##
class Bandit(Enemy):
    def __init__(self, tier = "3", name =  "Bandit", HP = 90, ATK = 20, hit_chance = .85, exp = 150):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class DarkKnight(Enemy):
    def __init__(self, tier = "3", name = "Dark Knight", HP = 120, ATK = 25, hit_chance = .8, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Barbarian(Enemy):
    def __init__(self, tier = "3", name = "Barbarian", HP = 135, ATK = 20, hit_chance = .85, exp = 160):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Sorcerer(Enemy):
    def __init__(self, tier = "3", name = "Sorcerer", HP = 80, ATK = 20, hit_chance = .8, exp = 130):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Assassin(Enemy):
    def __init__(self, tier = "3", name = "Assassin", HP = 100, ATK = 17, hit_chance = .9, exp = 120):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierThreeEnemies = [Bandit, DarkKnight, Barbarian, Sorcerer, Assassin]

##TIER 4 ENEMIES##
class Mummy(Enemy):
    def __init__(self, tier = "4", name = "Mummy", HP = 200, ATK = 35, hit_chance = .8, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Minotaur(Enemy):
    def __init__(self, tier = "4", name = "Minotaur", HP = 300, ATK = 30, hit_chance = .85, exp = 250):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Wraith(Enemy):
    def __init__(self, tier = "4", name = "Wraith", HP = 225, ATK = 40, hit_chance = .7, exp = 260):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Vampire(Enemy):
    def __init__(self, tier = "4", name = "Vampire", HP = 250, ATK = 35, hit_chance = .8, exp = 275):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Lycan(Enemy):
    def __init__(self, tier = "4", name = "Lycan", HP = 270, ATK = 50, hit_chance = .65, exp = 300):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierFourEnemies = [Mummy, Minotaur, Wraith, Vampire, Lycan]

##TIER 5 ENEMIES##
class Drake(Enemy):
    def __init__(self, tier = "5", name = "Drake", HP = 400, ATK = 60, hit_chance = .7, exp = 450):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Golem(Enemy):
    def __init__(self, tier = "5", name = "Golem", HP = 450, ATK = 35, hit_chance = .65, exp = 425):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Demon(Enemy):
    def __init__(self, tier = "5", name = "Demon", HP = 375, ATK = 70, hit_chance = .7, exp = 550):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Chimera(Enemy):
    def __init__(self, tier = "5", name = "Chimera", HP = 425, ATK = 55, hit_chance = 1, exp = 475):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

class Sentinel(Enemy):
    def __init__(self, tier = "5", name = "Sentinel", HP = 500, ATK = 30, hit_chance = .9, exp = 525):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

tierFiveEnemies = [Drake, Golem, Demon, Chimera, Sentinel]

##BOSSES##
class DireBear(Enemy):
    def __init__(self, tier = "1", name = "Dire Bear", HP = 50, ATK = 25, hit_chance = .1, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)
class HighOrc(Enemy):
    def __init__(self, tier = "2", name = "High Orc", HP = 50, ATK = 25, hit_chance = .1, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)
class CorruptedPaladin(Enemy):
    def __init__(self, tier = "3", name = "Corrupted Paladin", HP = 50, ATK = 25, hit_chance = .1, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)
class Lich(Enemy):
    def __init__(self, tier = "4", name = "Lich", HP = 50, ATK = 25, hit_chance = .1, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)
class RedDragon(Enemy): 
    def __init__(self, tier = "5", name = "Red Dragon", HP = 50, ATK = 25, hit_chance = .1, exp = 200):
        super().__init__(tier, name, HP, ATK, hit_chance, exp)

def getEnemies(tier):
    if tier == 1:
        return tierOneEnemies
    elif tier == 2:
        return tierTwoEnemies
    elif tier == 3:
        return tierThreeEnemies
    elif tier == 4:
        return tierFourEnemies
    elif tier == 5:
        return tierFiveEnemies
    else:
        return None
    
##Special Enemies##
# class specialEnemy(Enemy):
#     def __init__(self, name, HP, ATK, hit_chance, exp):
#         super().__init__(name, HP, ATK, hit_chance, exp)

# class mimic(specialEnemy):
#     def __init__(self, name, HP, ATK, hit_chance, exp):
#         super().__init__(name, HP, ATK, hit_chance, exp)

# class Slime(Enemy):
#     def __init__(self, name= "Slime", HP = 8, ATK = 2, hit_chance = .5, exp = 50):
#         super().__init__(name, HP, ATK, hit_chance, exp)











#UNUSED#
# class Gargoyle(Enemy):
#     def __init__(self, name = "Gargoyle", HP = 20, ATK = 8, hit_chance = .5, exp = 25):
#         super().__init__(name, HP, ATK, hit_chance, exp)

# class Lizardman(Enemy):
#     def __init__(self, name = "Lizardman", HP = 15, ATK = 7, hit_chance = .5, exp = 20):
#         super().__init__(name, HP, ATK, hit_chance, exp)

# class Harpy(Enemy):
#     def __init__(self, name = "Harpy", HP = 20, ATK = 8, hit_chance = .5, exp = 25):
#         super().__init__(name, HP, ATK, hit_chance, exp)


        
        
def attack(enemy, player):
    armorSum = 0
    for i, slot in enumerate(player.equipment):
        if isinstance(player.equipment[i], it.armor):
            armorPiece = player.equipment[i]
            armorSum += armorPiece.armor
    damageDone = enemy.ATK - armorSum
    if damageDone < 0:
        damageDone = 0
    if enemy.hit_chance >= rand.random():
        ts.scroll(enemy.name + " attacks " + player.name + " for " + str(damageDone) + " damage.")
        pc.player.updateHP(player, damageDone)
        ts.scroll(player.name + " has " + str(player.HP) + " HP remaining.")
    else:
        ts.scroll(enemy.name + " missed!")

def die(enemy):
    print(enemy.name + " has died.")

    
