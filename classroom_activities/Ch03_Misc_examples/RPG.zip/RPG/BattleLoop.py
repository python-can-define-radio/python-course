import PlayerCharacter as pc
import Enemies as en
import Text_Validation as  tv
import TextScroll
import Items as it
        
def battleLoop(player, enemy):
    while player.HP > 0 or enemy.HP > 0:
        print("What would you like to do?")
        print("1. Attack")
        print("2. Use Item")
        print("3. Flee")

        choice = int(tv.prompt('>', validator = tv.FunctionyValidator(tv.battleLoopValidate)))
        if choice == 1:
            pc.player.dealDamage(player, enemy)
        elif choice == 2:
            usableInventory = []
            i = 1
            for item in player.inventory:
                if isinstance(item, it.potion):
                    usableInventory.append(item)
                    TextScroll.scroll(f"{i}. {item.name} - {item.effect}")
                    i += 1
            if len(usableInventory) > 0:
                TextScroll.scroll("What would you like to use?")
                itemChoice = int(tv.prompt('>', validator = tv.FunctionyValidator(tv.digitValidate)))
                if itemChoice > 0 and itemChoice <= len(player.inventory):
                    item = usableInventory[itemChoice - 1]
                    if isinstance(item, it.healthPotion) or isinstance(item, it.manaPotion):
                        it.usePotion(player, item)
                        if player.HP >= player.maxHP:
                            TextScroll.scroll("You are already at full health.")
                            continue
                        elif player.MP >= player.maxMP:
                            TextScroll.scroll("You are already at full mana.")
                            continue
                        TextScroll.scroll(f"You used {item.name}.")
                    else:
                        TextScroll.scroll("You can't use that.")
                else:
                    TextScroll.scroll("Invalid choice.")
            else:
                TextScroll.scroll("You have no usable items.")
                input("Press enter to continue...")
                continue
        elif choice == 3:
            print("You flee.")
            return "defeat"
        if enemy.HP > 0:
            en.attack(enemy, player)
        if player.HP <= 0:
            pc.player.playerDie(player)
        if enemy.HP <= 0:
            en.die(enemy)
            pc.player.enemyKill(player, enemy)
            input("Press enter to continue...")
            return "victory"
        