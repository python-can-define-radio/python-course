import PlayerCharacter
import TextScroll

## Weapons
class weapon:
    def __init__(self, type, name, damage, value, equipped):
        self.type = type
        self.name = name
        self.damage = damage
        self.value = value
        self.equipped = equipped


#SWORDS#

#Rusty Sword
class rustySword(weapon):
    def __init__(self, type="warrior", name="Rusty Sword", damage=4, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"

#Iron Sword
class ironSword(weapon):
    def __init__(self, type="warrior", name="Iron Sword", damage=12, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Steel Sword
class steelSword(weapon):
    def __init__(self, type="warrior", name="Steel Sword", damage=25, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Platinum Sword
class platinumSword(weapon):
    def __init__(self, type="warrior", name="Platinum Sword", damage=40, value=10, equipped=False):
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"


##STAFFS##

#Wooden Staff
class woodenStaff(weapon):
    def __init__ (self, type="mage", name="Wooden Staff", damage=6, value=10, equipped=False, manaCost = 5):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Amethyst Staff
class amethystStaff(weapon):
    def __init__ (self, type="mage", name="Amethyst Staff", damage=12, value=10, equipped=False, manaCost = 5):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Ruby Staff
class rubyStaff(weapon):
    def __init__ (self, type="mage", name="Ruby Staff", damage=20, value=10, equipped=False, manaCost = 7):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Diamond Staff
class diamondStaff(weapon):
    def __init__ (self, type="mage", name="Diamond Staff", damage=35, value=10, equipped=False, manaCost = 10):
        self.manaCost = manaCost
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    

#BOWS#

#Wooden Bow
class bow(weapon):
    def __init__ (self, type="ranger", name="Wooden Bow", damage=3, value=10, equipped=False, hitChance=80):
        self.hitChance = hitChance
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Iron Bow
class ironBow(weapon):
    def __init__ (self, type="ranger", name="Iron Bow", damage=6, value=10, equipped=False, hitChance=85):
        self.hitChance = hitChance
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Recurve Bow
class recurveBow(weapon):
    def __init__ (self, type="ranger", name="Recurve Bow", damage=12, value=10, equipped=False, hitChance=90):
        self.hitChance = hitChance
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Longbow
class longbow(weapon):
    def __init__ (self, type="ranger", name="Longbow", damage=24, value=10, equipped=False, hitChance=95):
        self.hitChance = hitChance
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    

#DAGGERS#

#Rusty Dagger
class rustyDagger(weapon):
    def __init__(self, type="rogue", name="Rusty Dagger", damage=2, value=10, equipped=False, maxHit=3):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Iron Dagger
class ironDagger(weapon):
    def __init__(self, type="rogue", name="Iron Dagger", damage=4, value=10, equipped=False, maxHit=4):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Obsidian Dagger
class obsidianDagger(weapon):
    def __init__(self, type="rogue", name="Obsidian Dagger", damage=7, value=10, equipped=False, maxHit=5):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    
#Dragonglass Dagger
class dragonglassDagger(weapon):
    def __init__(self, type="rogue", name="Dragonglass Dagger", damage=16, value=10, equipped=False, maxHit=6):
        self.maxHit = maxHit
        super().__init__(type, name, damage, value, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value})"
    


##Armor
class armor:
    def __init__(self, type, name, armor, value, equipped):
        self.type = type
        self.name = name
        self.armor = armor
        self.value = value
        self.equipped = equipped


#LEATHER#

#Leather Cap
class leatherCap(armor):
    def __init__(self, type="head", name="Leather Cap", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Cuirass
class leatherCuirass(armor):
    def __init__(self, type="chest", name="Leather Vest", armor=3, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Gloves
class leatherGloves(armor):
    def __init__(self, type="hands", name="Leather Gloves", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"

#Leather Pants
class leatherPants(armor):
    def __init__(self, type="legs", name="Leather Pants", armor=2, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Leather Boots
class leatherBoots(armor):
    def __init__(self, type="feet", name="Leather Boots", armor=1, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    

#IRON#

#Iron Helmet
class ironHelmet(armor):
    def __init__(self, type="head", name="Iron Helmet", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Chestplate
class ironChestplate(armor):
    def __init__(self, type="chest", name="Iron Chestplate", armor=8, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Gauntlets
class ironGauntlets(armor):
    def __init__(self, type="hands", name="Iron Gauntlets", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Greaves
class ironGreaves(armor):
    def __init__(self, type="legs", name="Iron Greaves", armor=7, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Iron Boots
class ironBoots(armor):
    def __init__(self, type="feet", name="Iron Boots", armor=6, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    

#PLATINUM#

#Platinum Headgear
class platinumHeadgear(armor):
    def __init__(self, type="head", name="Platinum Headgear", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Chestplate
class platinumChestplate(armor):
    def __init__(self, type="chest", name="Platinum Chestplate", armor=15, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Gauntlets
class platinumGauntlets(armor):
    def __init__(self, type="hands", name="Platinum Gauntlets", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Greaves
class platinumGreaves(armor):
    def __init__(self, type="legs", name="Platinum Greaves", armor=13, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"
    
#Platinum Boots
class platinumBoots(armor):
    def __init__(self, type="feet", name="Platinum Boots", armor=10, value=10, equipped=False):
        super().__init__(type, name, armor, value, equipped)
    def __str__(self):
        return f"{self.name} (Armor: {self.armor}, Value: {self.value})"


#ARROWS#

class arrow:
    def __init__(self, name, damage, value, amount, equipped):
        self.name = name
        self.damage = damage
        self.amount = amount
        self.value = value
        self.equipped = equipped


#Iron Arrow

class ironArrow(arrow):
    def __init__(self, name="Iron Arrow", damage=3, value=10, amount=0, equipped=False):
        super().__init__(name, damage, value, amount, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity


#Steel Arrow

class steelArrow(arrow):
    def __init__(self, name="Steel Arrow", damage=6, value=10, amount=0, equipped=False):
        super().__init__(name, damage, value, amount, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity


#Platinum Arrow

class platinumArrow(arrow):
    def __init__(self, name="Platinum Arrow", damage=9, value=10, amount=0, equipped=False):
        super().__init__(name, damage, value, amount, equipped)
    def __str__(self):
        return f"{self.name} (Damage: {self.damage}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity

##POTIONS##
class potion:
    def __init__(self, type, name, effect, value, amount, equipped):
        self.type = type
        self.name = name
        self.effect = effect
        self.value = value
        self.amount = amount
        self.equipped = equipped


#Health Potion

class healthPotion(potion):
    def __init__(self, type = "health", name="Health Potion", effect="Restores 20 HP", value=10, amount=0, equipped=False, healAmount=20):
        super().__init__(type, name, effect, value, amount, equipped)
        self.healAmount = healAmount
    def __str__(self):
        return f"{self.name} (Effect: {self.effect}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity


#Mana Potion

class manaPotion(potion):
    def __init__(self, type = "mana", name="Mana Potion", effect="Restores 20 MP", value=10, amount=0, equipped=False, manaAmount=20):
        super().__init__(type, name, effect, value, amount, equipped)
        self.manaAmount = manaAmount
    def __str__(self):
        return f"{self.name} (Effect: {self.effect}, Value: {self.value}, Amount: {self.amount})"    
    def add(self, quantity):
        self.amount += quantity

#Use potion function
def usePotion(player, item):
    # Check if the item is usable
    if player.HP == player.maxHP and item.type == "health":
        TextScroll.scroll(f"{player.name} is already at max HP!")
        return
    if player.MP == player.maxMP and item.type == "mana":
        TextScroll.scroll(f"{player.name} is already at max MP!")
        return
    # Use item 
    TextScroll.scroll(f"{item.name} used!")
    if item.type == "health":
        player.HP += item.healAmount
        if player.HP > player.maxHP:
            player.HP = player.maxHP
        TextScroll.scroll(f"{player.name} now has {player.HP} HP!")
    elif item.type == "mana":
        player.MP += item.manaAmount
        if player.MP > player.maxMP:
            player.MP = player.maxMP
        TextScroll.scroll(f"{player.name} now has {player.MP} MP!")
    item.amount -= 1
    if item.amount <= 0:
        player.inventory.remove(item)


# Add to inventory function
def addToInventory(player, item, quantity):
    if isinstance(item, arrow) or isinstance(item, potion):
        for inv_item in player.inventory:
            if isinstance(inv_item, type(item)):  # Same type of arrow
                inv_item.amount += quantity
                return
        # If not found, set amount and add new
        item.amount = quantity
        player.inventory.append(item)
    else:
        player.inventory.append(item)

tierOneLootPool = [leatherCap(), leatherCuirass(), leatherGloves(), leatherPants(), leatherBoots(), rustySword(), rustyDagger(), woodenStaff(), bow()]
tierTwoLootPool = [leatherCap(), leatherCuirass(), leatherGloves(), leatherPants(), leatherBoots(), ironSword(), ironDagger(), amethystStaff(), ironBow()]
tierThreeLootPool = [ironHelmet(), ironChestplate(), ironGauntlets(), ironGreaves(), ironBoots(), steelSword(), obsidianDagger(), rubyStaff(), recurveBow()]
tierFourLootPool = [ironHelmet(), ironChestplate(), ironGauntlets(), ironGreaves(), ironBoots(), platinumSword(), dragonglassDagger(), diamondStaff(), longbow()]
tierFiveLootPool = [platinumHeadgear(), platinumChestplate(), platinumGauntlets(), platinumGreaves(), platinumBoots(), platinumSword(), dragonglassDagger(), diamondStaff(), longbow()]