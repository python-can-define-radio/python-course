import random
import time
import math
import TextScroll
import Items
import Text_Validation as tv
def calculateMaxHP(self):
    class_settings = {
        "Warrior": {"baseHP": 100, "r":1.04},
        "Rogue": {"baseHP": 70, "r":1.03},
        "Mage": {"baseHP": 60, "r":1.025},
        "Ranger": {"baseHP": 80, "r":1.03},
    }

    settings = class_settings.get(self.playerClass, {"baseHP":70, "r":1.03})
    base = settings["baseHP"]
    r = settings["r"]
    con = self.CON

    scaled_hp = base * (1 + r ** con)
    return int(scaled_hp)

class player:
    def __init__(self, name, playerClass, level, exp, nextLevelExp, maxHP, maxMP, HP, MP, damage, manaUsed, gold, equippedWeapon, equippedArmorSlots, inventory, equipment, equippedArrow, currentTier, baseHP):
        self.name = name
        self.playerClass = playerClass
        self.level = level
        damage = 0
        self.exp = exp
        self.nextLevelExp = int((math.sqrt(level) * 100) // 1)
        self.maxHP = 0
        self.maxMP = 0
        self.HP = 0
        self.MP = 0
        self.gold = gold
        self.equippedWeapon = equippedWeapon
        self.equippedArmorSlots = {
            "head": None,
            "chest": None,
            "legs": None,
            "feet": None,
            "hands": None}
        self.inventory = inventory
        self.equipment = equipment
        self.equippedArrow = equippedArrow
        self.currentTier = currentTier
        self.baseHP = 0


    def printStats(self):
        print("Name: " + self.name)
        print("Level: " + str(self.level))
        print("Class: " + self.playerClass)
        print("HP: " + str(self.HP) + "/" + str(self.maxHP))
        print("MP: " + str(self.MP) + "/" + str(self.maxMP))
        print("EXP: " + str(self.exp) + "/" + str(self.nextLevelExp))
        print("STR: " + str(self.STR))
        print("DEX: " + str(self.DEX))
        print("INT: " + str(self.INT))
        print("CON: " + str(self.CON))
        print("WIS: " + str(self.WIS))
        print("CHA: " + str(self.CHA))
        print("LUK: " + str(self.LUK))
        print("Gold: " + str(self.gold))

    def makeWarrior(self):
            self.STR = 3
            self.DEX = 1
            self.INT = 1
            self.CON = 4
            self.WIS = 1
            self.CHA = 1
            self.LUK = 1
            self.maxHP = calculateMaxHP(self)
            self.maxMP = self.WIS * 10
            self.HP = self.maxHP
            self.MP = self.maxMP
            self.playerClass = "Warrior"
            self.baseHP = 100

    def makeRogue(self):
            self.STR = 2
            self.DEX = 1
            self.INT = 1
            self.CON = 2
            self.WIS = 1
            self.CHA = 3
            self.LUK = 1
            self.maxHP = calculateMaxHP(self)
            self.maxMP = self.WIS * 10
            self.HP = self.maxHP
            self.MP = self.maxMP
            self.playerClass = "Rogue"
            self.baseHP = 70

    def makeMage(self):
            self.STR = 2
            self.DEX = 1
            self.INT = 3
            self.CON = 1
            self.WIS = 2
            self.CHA = 1
            self.LUK = 1
            self.maxHP = calculateMaxHP(self)
            self.maxMP = self.WIS * 10
            self.HP = self.maxHP
            self.MP = self.maxMP
            self.playerClass = "Mage"
            self.baseHP = 60

    def makeRanger(self):
            self.STR = 2
            self.DEX = 3
            self.INT = 1
            self.CON = 2
            self.WIS = 1
            self.CHA = 1
            self.LUK = 1
            self.maxHP = calculateMaxHP(self)
            self.maxMP = self.WIS * 10
            self.HP = self.maxHP
            self.MP = self.maxMP
            self.playerClass = "Ranger"
            self.baseHP = 80

    def setMaxHP(self):
        self.maxHP = calculateMaxHP(self)
        self.HP = self.maxHP

    def updateHP(self, damage):
        self.HP = self.HP - damage
        if self.HP < 0:
            self.HP = 0
        return self.HP

    def updateMP(self, manaUsed):
        self.MP = self.MP - manaUsed
        if self.MP < 0:
            self.MP = 0
        return self.MP
    
    def equipWeapon(self, weapon):
        if self.equippedWeapon:
            self.inventory.append(self.equippedWeapon)
        self.equippedWeapon = weapon
        self.equipment.append(weapon)
        self.inventory.remove(weapon)

    def equipArmor(self, armor):
        slot = armor.type

        if slot not in self.equippedArmorSlots:
            TextScroll.scroll(f"Unknown armor slot: {slot}")
            return

        current_equipped = self.equippedArmorSlots.get(slot)

        # Unequip current armor if present
        if current_equipped:
            TextScroll.scroll(f"Unequipping current: {current_equipped.name}")
            if current_equipped not in self.inventory:
                self.inventory.append(current_equipped)
            if current_equipped in self.equippedArmorSlots.values():
                del self.equippedArmorSlots[slot]
            if current_equipped in self.equipment:
                self.equipment.remove(current_equipped)

        # Equip new armor
        self.equippedArmorSlots[slot] = armor
        if armor not in self.equippedArmorSlots.values():
            self.equippedArmorSlots[slot] = armor
        if armor not in self.equipment:
            self.equipment.append(armor)
        if armor in self.inventory:
            self.inventory.remove(armor)

        TextScroll.scroll(f"{armor.name} equipped to {slot}")


    def equipArrow(self, arrow):
        if type(arrow) == type(self.equippedArrow):
            self.equippedArrow.amount += arrow.amount
            self.inventory.remove(arrow)
        elif self.equippedArrow == None:
            self.equippedArrow = arrow
            self.inventory.remove(arrow)
            self.equipment.append(arrow)
        else:
            Items.addToInventory(self, self.equippedArrow, self.equippedArrow.amount)
            self.equippedArrow = arrow
            self.inventory.remove(arrow)
            self.equipment.append(arrow)

    def dealDamage(self, enemy):
        if self.equippedWeapon == None:
            damage = self.STR
            enemy.HP = enemy.HP - damage
            if enemy.HP <= 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has 0 HP remaining.")
            if enemy.HP > 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has " + str(enemy.HP) + " HP remaining.")

        elif self.equippedWeapon.type == "mage":
            damage = (self.INT + self.equippedWeapon.damage)
            enemy.HP = enemy.HP - damage
            self.MP = (self.MP - self.equippedWeapon.manaCost)
            TextScroll.scroll(f"{self.name} has {self.MP} mana remaining.")
            if enemy.HP <= 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has 0 HP remaining.")
            if enemy.HP > 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has " + str(enemy.HP) + " HP remaining.")

        elif self.equippedWeapon.type == "ranger":
            if self.equippedArrow == None:
                TextScroll.scroll("...You don't have any arrows!")
                return
            elif self.equippedArrow.amount > 0:
                hit = random.randint(0,100)
                if hit < self.equippedWeapon.hitChance:
                    damage = (self.DEX + self.equippedWeapon.damage + self.equippedArrow.damage)
                    enemy.HP = enemy.HP - damage
                    self.equippedArrow.amount -= 1
                    TextScroll.scroll(f"{self.name} has {self.equippedArrow.amount} {self.equippedArrow.name}s remaining")
                    if enemy.HP <= 0:
                        print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                        print(enemy.name + " has 0 HP remaining.")
                    if enemy.HP > 0:
                        print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                        print(enemy.name + " has " + str(enemy.HP) + " HP remaining.")
                else:
                    damage = 0
                    enemy.HP = enemy.HP - damage
                    self.equippedArrow.amount -= 1
                    TextScroll.scroll("You missed!")
            else:
                TextScroll.scroll("...You don't have any arrows!")
        elif self.equippedWeapon.type == "rogue":
            hitAmount = random.randint(2, self.equippedWeapon.maxHit)
            totalDamage = 0
            for i in range (hitAmount):
                TextScroll.scroll(f"Hit {i + 1} time!")
                damage = (self.CHA + self.equippedWeapon.damage)
                enemy.HP = enemy.HP - damage
                totalDamage += damage
            if enemy.HP <= 0:
                print(self.name + " dealt " + str(totalDamage) + " damage to " + enemy.name)
                print(enemy.name + " has 0 HP remaining.")
            if enemy.HP > 0:
                print(self.name + " dealt " + str(totalDamage) + " damage to " + enemy.name)
                print(enemy.name + " has " + str(enemy.HP) + " HP remaining.")                       
        else:
            if self.STR < 5:
                damage = (self.STR + self.equippedWeapon.damage)
            elif 5 <= self.STR < 10:
                damage = (self.STR * 2) + self.equippedWeapon.damage
            elif self.STR >= 10:
                damage = (self.STR * 4) + self.equippedWeapon.damage
            enemy.HP = enemy.HP - damage
            if enemy.HP <= 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has 0 HP remaining.")
            if enemy.HP > 0:
                print(self.name + " dealt " + str(damage) + " damage to " + enemy.name)
                print(enemy.name + " has " + str(enemy.HP) + " HP remaining.")

    def playerDie(self):
        print(self.name + " has died.")
        print("Game Over")
        exit()

    def enemyKill(self, enemy):
        if enemy.HP <= 0:
            self.exp += enemy.exp
            print(self.name + " has gained " + str(enemy.exp) + " EXP.")
            print(self.name + " has " + str(self.nextLevelExp - self.exp) + " EXP remaining until level up.")
            if self.exp >= self.nextLevelExp:
                player.levelUp(self)


    def levelUp(self):
        self.level += 1
        self.nextLevelExp = int((math.sqrt(self.level) * 100) // 1)
        print(self.name + " has leveled up to level " + str(self.level))
        value = 3
        for i in range(3):
            print(f"You can increase {value} attributes by 1.")
            print("1. STR")
            print("2. DEX")
            print("3. INT")
            print("4. CON")
            print("5. WIS")
            print("6. CHA")
            print("7. LUK")

            choice = tv.prompt(">", validator = tv.FunctionyValidator(tv.levelUpValidate))
            if choice == "1":
                self.STR += 1
            elif choice == "2":
                self.DEX += 1
            elif choice == "3":
                self.INT += 1
            elif choice == "4":
                self.CON += 1
            elif choice == "5":
                self.WIS += 1
            elif choice == "6":
                self.CHA += 1
            elif choice == "7":
                self.LUK += 1
            else:
                print("Invalid input")
            self.maxHP = int(round(self.baseHP + (1.5 * (self.CON * 5))))
            self.maxMP = self.WIS * 10
            self.HP = self.maxHP
            self.MP = self.maxMP
            self.exp = 0
            player.printStats(self)
            value -= 1

    def printInventory(self):
        inventoryDisplay = []
        for item in self.inventory:
            inventoryDisplay.append(item)
        for i, item in enumerate(inventoryDisplay, start=1):
            TextScroll.scroll((f"{i}. {item.name}"))
        TextScroll.scroll("What item would you like to inspect?\n0 to quit")

    def printEquipped(self):
        TextScroll.scroll("Equipped Items:")
        if self.equippedWeapon:
            TextScroll.scroll(f"1. Weapon: {self.equippedWeapon.name}")
        else:
            TextScroll.scroll("1. Weapon: None")

        if self.equippedArrow:
            TextScroll.scroll(f"2. Arrow: {self.equippedArrow.name}")
        else:
            TextScroll.scroll("2. Arrow: None")
            
        i = 3
        for slot, armor in self.equippedArmorSlots.items():
            TextScroll.scroll(f"{i}. {slot.capitalize()}: {armor.name if armor else 'None'}")
            i += 1
        TextScroll.scroll("What item would you like to inspect?\n0 to quit")

    def displayInventory(self):
        if len(self.inventory) > 0:
            valid = False
            while not valid:
                self.printInventory()
                try:
                    choice = int(input("")) - 1
                except ValueError:
                    print("Please enter a valid number.")
                    continue
                if choice == -1:
                    valid = True
                    continue

                if 0 <= choice < len(self.inventory):
                    selected_item = self.inventory[choice]
                    TextScroll.scroll(str(selected_item))
                    if isinstance(selected_item, Items.weapon) or isinstance(selected_item, Items.armor) or isinstance(selected_item, Items.arrow):
                        TextScroll.scroll("Equip? (y/n)")
                    elif isinstance(selected_item, Items.potion):
                        TextScroll.scroll("Use? (y/n)")

                    equip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))

                    if equip.lower() == "y":
                        if isinstance(selected_item, Items.weapon):
                            self.equipWeapon(selected_item)
                            self.equipment.append(selected_item)
                            TextScroll.scroll(f"{selected_item.name} equipped!")
                            valid = True

                        elif isinstance(selected_item, Items.armor):
                            self.equipArmor(selected_item)
                            valid = True

                        elif isinstance(selected_item, Items.arrow):
                            self.equipArrow(selected_item)
                            self.equipment.append(selected_item)
                            TextScroll.scroll(f"{selected_item.name} equipped!")
                            valid = True

                        elif isinstance(selected_item, Items.potion):
                            Items.usePotion(self, selected_item)
                            valid = True

                    elif equip.lower() == "n":
                        print("Canceled.")
                    else:
                        print("Invalid input")
        else:
            TextScroll.scroll("Inventory is empty.")

    def displayEquipped(self):
        if len(self.equipment) > 0:
            valid = False
            choice = None
            while not valid:
                self.printEquipped()
                try:
                    choice = int(input(""))
                except ValueError:
                    print("Please enter a valid number.")

                if choice == 1 and self.equippedWeapon != None:
                    selected_item = self.equippedWeapon
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedWeapon = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 2 and self.equippedArrow != None:
                    selected_item = self.equippedArrow
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        Items.addToInventory(self, selected_item)
                        self.equippedArrow = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 3 and self.equippedArmorSlots["head"] != None:
                    slot = "head"
                    selected_item = self.equippedArmorSlots[slot]
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedArmorSlots[slot] = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 4 and self.equippedArmorSlots["chest"] != None:
                    slot = "chest"
                    selected_item = self.equippedArmorSlots[slot]
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedArmorSlots[slot] = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 5 and self.equippedArmorSlots["legs"] != None:
                    slot = "legs"
                    selected_item = self.equippedArmorSlots[slot]
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedArmorSlots[slot] = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 6 and self.equippedArmorSlots["feet"] != None:
                    slot = "feet"
                    selected_item = self.equippedArmorSlots[slot]
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedArmorSlots[slot] = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 7 and self.equippedArmorSlots["hands"] != None:
                    slot = "hands"
                    selected_item = self.equippedArmorSlots[slot]
                    TextScroll.scroll(str(selected_item))
                    TextScroll.scroll("Unequip? (y/n)")
                    unequip = tv.prompt('>', validator=tv.FunctionyValidator(tv.ynValidate))
                    if unequip.lower() == "y":
                        self.inventory.append(selected_item)
                        self.equippedArmorSlots[slot] = None
                        self.equipment.remove(selected_item)
                        TextScroll.scroll(f"{selected_item.name} unequipped!")
                        valid = True
                    elif unequip.lower() == "n":
                        print("Canceled.")
                        valid = True
                elif choice == 0:
                    valid = True
                    continue
                else:
                    print("Invalid input")
        else:
            TextScroll.scroll("No items currently equipped.")