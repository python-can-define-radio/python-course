import PlayerCharacter as pc
import Enemies as en
import BattleLoop as bl
import TextScroll as ts
import Text_Validation as tv
import Encounters as ec
import Items as it

playerCharacter = pc.player("Player", "", 1, 0, 100, 0, 0, 0, 0, 0, 0, 0, None, {}, [], [], None, 1, 0)
playerCharacter.name = "Matt"
pc.player.makeWarrior(playerCharacter)
roomCounter = 0
it.addToInventory(playerCharacter, it.healthPotion(), 1)
ec.gameplayLoop(playerCharacter, roomCounter)
