import random
import time
import math
import PlayerCharacter as pc
import Enemies as en
import Encounters
import BattleLoop as bl
import Title
import Text_Validation as tv
import TextScroll
import Items as it

Title.TitleScreen()
input("Press enter to continue...")

TextScroll.scroll("Greetings, what are you called?")
valid = False
while valid == False:
    name = (tv.prompt('>', validator = tv.FunctionyValidator(tv.isAlphaValidate)))
    TextScroll.scroll(f"You're name is {name}... are you sure? (y/n)")
    confirm = (tv.prompt('>', validator = tv.FunctionyValidator(tv.ynValidate)))
    if confirm == "y":
        valid = True
    elif confirm == "n":
        TextScroll.scroll("What is your name then?")

playerCharacter = pc.player(name, "", 1, 0, 100, 0, 0, 0, 0, 0, 0, 0, None, {}, [], [], None, 1, 0)

TextScroll.scroll(f"I see... what is your background {name}?")
TextScroll.scroll("1. Warrior")
TextScroll.scroll("2. Rogue")
TextScroll.scroll("3. Mage")
TextScroll.scroll("4. Ranger")
valid = False
while valid == False:
    classSelection = (tv.prompt('>', validator = tv.FunctionyValidator(tv.classValidate)))
    if classSelection == "1":
        playerCharacter.makeWarrior()
        valid = True
    elif classSelection == "2":
        playerCharacter.makeRogue()
        valid = True
    elif classSelection == "3":
        playerCharacter.makeMage()
        valid = True
    elif classSelection == "4":
        playerCharacter.makeRanger()
        valid = True
    TextScroll.scroll(f"You are a {playerCharacter.playerClass}? Are you sure? (y/n)")
    confirm = (tv.prompt('>', validator = tv.FunctionyValidator(tv.ynValidate)))
    if confirm == "y":
        valid = True
    elif confirm == "n":
        TextScroll.scroll("What is your class then?")
        valid = False

TextScroll.scroll(f"Very well {playerCharacter.playerClass}, examine yourself closely:")
playerCharacter.printStats()
input("Press enter to continue...")

TextScroll.scroll(f"Well {playerCharacter.name}, unfortunately, you are dead.\nBUT\nYou have arrived at the gates of the Eternal Dungeon.\n")
TextScroll.scroll("Consider yourself lucky, not many adventures make the cut to end up here.")
TextScroll.scroll("Why don't you get started? If you survive, I'll consider telling you more...")

TextScroll.scrollSlow("Enter the gate...")

print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣀⣀⣀⣀⣀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⣿⣿⣿⣿⡇⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⣠⡀⠀⠀⣠⣴⣾⡀⠻⠿⠿⠿⠀⣾⣶⣄⡀⠀⢀⣄⠀⠀⠀⠀⠀")
print("⠀⠀⠀⢀⣼⣿⣿⣶⣄⠙⠟⢉⣠⣤⡄⢠⣤⣤⣈⠛⠋⣀⣴⣿⣿⣷⡀⠀⠀⠀")
print("⠀⠀⠀⠀⠉⠛⠻⠿⡿⠁⣴⣿⣿⣿⡇⢸⣿⣿⣿⣦⡀⢻⡿⠟⠛⠉⠁⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⣶⣤⠀⢸⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣷⠀⣤⣶⡆⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠘⠿⠿⠀⣾⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⠻⠿⠃⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⣶⣶⣶⣶⠀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⢰⣶⣶⣶⠀⠀⠀⠀")
print("⠀⠀⠀⠀⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⢸⣿⣿⣿⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⢠⣤⣤⠀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⢠⣤⡄⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠘⠛⠛⠀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⠘⠛⠃⠀⠀⠀⠀⠀")
print("⠀⠀⠀⢸⣿⣿⣿⣿⠀⣿⣿⣿⣿⣿⡇⢸⣿⣿⣿⣿⣿⠀⢸⣿⣿⣿⡇⠀⠀⠀")
print("⠀⠀⠀⠸⠿⠿⠿⠿⠀⠻⠿⠿⠿⠿⠇⠘⠿⠿⠿⠿⠿⠀⠸⠿⠿⠿⠇⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠀⣠⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣶⣄⠀⠀⠀⠀⠀⠀⠀")
print("⠀⠀⠀⠀⠀⠀⠈⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠉⠁⠀⠀⠀⠀⠀⠀")

input("Press enter to begin...")

Encounters.gameplayLoop(playerCharacter, 0)



