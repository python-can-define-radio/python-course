import PlayerCharacter
import Enemies
import BattleLoop
import TextScroll
import Text_Validation as tv
import random
import Items

def firstEncounter(player):
    if player.playerClass == "Ranger":
        player.inventory.append(Items.bow())
        Items.addToInventory(player, Items.ironArrow(), 10)
    if player.playerClass == "Warrior":
        player.inventory.append(Items.rustySword())
    if player.playerClass == "Mage":
        player.inventory.append(Items.woodenStaff())
    if player.playerClass == "Rogue":
        player.inventory.append(Items.rustyDagger())
    endOfRoom(player)
    TextScroll.scroll("You enter the dungeon and see a Giant Rat!.")
    TextScroll.scroll("What would you like to do?")
    TextScroll.scroll("1.Attack\n2.Run")
    valid = False
    while valid == False:
        decision = int(tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate)))
        if decision == 1:
            enemy = Enemies.GiantRat()
            result = BattleLoop.battleLoop(player, enemy)
            valid = True
        elif decision == 2:
                TextScroll.scroll("Foolish, you cannot escape the dungeon.")

    if result == "victory":
        enemy = None
        endOfRoom(player)

def reward(player):
    TextScroll.scroll("You find a chest.")
    gold = random.randint(30, 100)
    playerMultiplier = player.LUK * 1.1
    gold = round(gold * playerMultiplier)
    player.gold += gold
    TextScroll.scroll(f"You find {gold} gold.")

def enemyRoom(player):
    enemyList = []
    enemyList = Enemies.getEnemies(int(player.currentTier))
    randomEnemyClass = random.choice(enemyList)
    randomEnemy = randomEnemyClass()
    TextScroll.scroll(f"You enter a room and see an {randomEnemy.name}.")
    TextScroll.scroll("It's coming right for you!")
    input(TextScroll.scroll("Press enter to continue..."))
    result = BattleLoop.battleLoop(player, randomEnemy)
    if result == "victory":
        reward(player)
        endOfRoom(player)

def endOfRoom(player):
    valid = False
    roomInspected = False
    while valid == False:
        TextScroll.scroll("What would you like to do?\n1. Inventory\n2. Equipment\n3. Examine the room\n4. View Stats\n5. Continue")
        choice = (tv.prompt('>', validator = tv.FunctionyValidator(tv.endOfRoomValidate)))
        if choice == "1":
            PlayerCharacter.player.displayInventory(player)
            input(TextScroll.scroll("Press enter to continue..."))
        elif choice == "2":
            PlayerCharacter.player.displayEquipped(player)
            input(TextScroll.scroll("Press enter to continue..."))
        elif choice == "3":
            if roomInspected == False:
                inspectRoom(player)
                input(TextScroll.scroll("Press enter to continue..."))
                roomInspected = True
            else:
                TextScroll.scroll("You already inspected the room.")
                input(TextScroll.scroll("Press enter to continue..."))
        elif choice == "4":
            PlayerCharacter.player.printStats(player)
            input(TextScroll.scroll("Press enter to continue..."))
        elif choice == "5":
            TextScroll.scroll("You continue on your journey.")
            input(TextScroll.scroll("Press enter to continue..."))
            valid = True

def inspectRoom(player):
    TextScroll.scroll("You take a moment to look around the room to see if you can find anything useful.")
    detectItem = random.randint(1, 100)
    item = None
    if detectItem <= 20:
        item = Items.healthPotion()
        Items.addToInventory(player, item, 1)
        TextScroll.scroll(f"You found a {item.name}!")
    elif 20 < detectItem <= 40:
        item = Items.manaPotion()
        Items.addToInventory(player, item, 1)
        TextScroll.scroll(f"You found a {item.name}!")
    if 40 < detectItem <= 50:
        if player.currentTier == 1:
            item = random.choice(Items.tierOneLootPool)
            TextScroll.scroll(f"You found a {item.name}!")
            player.inventory.append(item)
        elif player.currentTier == 2:
            item = random.choice(Items.tierTwoLootPool)
            TextScroll.scroll(f"You found a {item.name}!")
            player.inventory.append(item)
        elif player.currentTier == 3:
            item = random.choice(Items.tierThreeLootPool)
            TextScroll.scroll(f"You found a {item.name}!")
            player.inventory.append(item)
        elif player.currentTier == 4:
            item = random.choice(Items.tierFourLootPool)
            TextScroll.scroll(f"You found a {item.name}!")
            player.inventory.append(item)
        elif player.currentTier == 5:
            item = random.choice(Items.tierFiveLootPool)
            TextScroll.scroll(f"You found a {item.name}!")
            player.inventory.append(item)
    elif 50 < detectItem <= 70:
        if player.currentTier == 1:
            item = Items.ironArrow()
            amountArrows = random.randint(5, 10)
            Items.addToInventory(player, item, amountArrows)
            TextScroll.scroll(f"You found {amountArrows} {item.name}s!")
        elif player.currentTier == 2:
            item = Items.ironArrow()
            amountArrows = random.randint(10, 15)
            Items.addToInventory(player, item, amountArrows)
            TextScroll.scroll(f"You found {amountArrows} {item.name}s!")
        elif player.currentTier == 3:
            item = Items.steelArrow()
            amountArrows = random.randint(15, 20)
            Items.addToInventory(player, item, amountArrows)
            TextScroll.scroll(f"You found {amountArrows} {item.name}s!")
        elif player.currentTier == 4:
            item = Items.steelArrow()
            amountArrows = random.randint(20, 25)
            Items.addToInventory(player, item, amountArrows)
            TextScroll.scroll(f"You found {amountArrows} {item.name}s!")
        elif player.currentTier == 5:
            item = Items.platinumArrow()
            amountArrows = random.randint(25, 30)
            Items.addToInventory(player, item, amountArrows)
            TextScroll.scroll(f"You found {amountArrows} {item.name}s!")
    elif 70 < detectItem <= 100:
        TextScroll.scroll("You find nothing of interest.")
    
##TREASURE ROOMS##

#Tier 1
def tierOneTreasureRoom(player, roomCounter):
    TextScroll.scroll("You enter a long forgotten supply cache, smashed crates and barrels are strewn about.")
    TextScroll.scroll("You see a wooden chest that looks mostly intact.")
    TextScroll.scroll("1. Open the chest\n2. Ignore it and continue.")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        loot = random.randint(1, 100)
        print(loot)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierOneLootPool)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(1, 2)
            TextScroll.scroll(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!")
            player.inventory.append(item1)
            Items.addToInventory(player, item2, quantity)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(1, 2)
            TextScroll.scroll(f"You found a {item1.name} (Quantity: {quantity})!")
            Items.addToInventory(player, item1, quantity)
        gold = random.randint(30, 100)
        playerMultiplier = player.LUK * 1.1
        gold = round(gold * playerMultiplier)
        player.gold += gold
        TextScroll.scroll(f"You found {gold} gold")
    elif choice == "2":
        TextScroll.scroll("You continue on your journey...")
    endOfRoom(player)
    roomCounter += 1

#Tier 2
def tierTwoTreasureRoom(player, roomCounter):
    TextScroll.scroll("You enter a modest storage room, supplies are strewn about.")
    TextScroll.scroll("There is a promising looking box half open in the corner.")
    TextScroll.scroll("1. Look inside\n2. Ignore it and continue.")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        loot = random.randint(1, 100)
        print(loot)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierTwoLootPool)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(1, 3)
            TextScroll.scroll(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!")
            player.inventory.append(item1)
            Items.addToInventory(player, item2, quantity)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(1, 3)
            TextScroll.scroll(f"You found a {item1.name} (Quantity: {quantity})!")
            Items.addToInventory(player, item1, quantity)
        gold = random.randint(50, 120)
        playerMultiplier = player.LUK * 1.1
        gold = round(gold * playerMultiplier)
        player.gold += gold
        TextScroll.scroll(f"You found {gold} gold")
    elif choice == "2":
        TextScroll.scroll("You continue on your journey...")
    endOfRoom(player)
    roomCounter += 1

#Tier 3
def tierThreeTreasureRoom(player, roomCounter):
    TextScroll.scroll("You find yourself in a brightly lit armory, assorted weapon racks and armor stands line the walls.")
    TextScroll.scroll("A particular shelf of supplies sticks out to you.")
    TextScroll.scroll("1. Inspect the shelf\n2. Ignore it and continue.")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        loot = random.randint(1, 100)
        print(loot)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierThreeLootPool)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(2, 4)
            TextScroll.scroll(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!")
            player.inventory.append(item1)
            Items.addToInventory(player, item2, quantity)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(2, 4)
            TextScroll.scroll(f"You found a {item1.name} (Quantity: {quantity})!")
            Items.addToInventory(player, item1, quantity)
        gold = random.randint(80, 150)
        playerMultiplier = player.LUK * 1.1
        gold = round(gold * playerMultiplier)
        player.gold += gold
        TextScroll.scroll(f"You found {gold} gold")
    elif choice == "2":
        TextScroll.scroll("You continue on your journey...")
    endOfRoom(player)
    roomCounter += 1

#Tier 4
def tierFourTreasureRoom(player, roomCounter):
    TextScroll.scroll("You enter a lavishly decorated room, torches line the walls and a large chandelier hangs from the ceiling.")
    TextScroll.scroll("A large ornate chest sits in the center.")
    TextScroll.scroll("1. Open the Chest\n2. Ignore it and continue.")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        loot = random.randint(1, 100)
        print(loot)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierFourLootPool)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(2, 5)
            TextScroll.scroll(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!")
            player.inventory.append(item1)
            Items.addToInventory(player, item2, quantity)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(2, 5)
            TextScroll.scroll(f"You found a {item1.name} (Quantity: {quantity})!")
            Items.addToInventory(player, item1, quantity)
        gold = random.randint(90, 200)
        playerMultiplier = player.LUK * 1.1
        gold = round(gold * playerMultiplier)
        player.gold += gold
        TextScroll.scroll(f"You found {gold} gold")
    elif choice == "2":
        TextScroll.scroll("You continue on your journey...")
    endOfRoom(player)
    roomCounter += 1

#Tier 5
def tierFiveTreasureRoom(player, roomCounter):
    TextScroll.scroll("You enter a stark, immaculate room, the walls lined with gleaming weapons of war.")
    TextScroll.scroll("A black marble table in the center looks to have some supplies on it.")
    TextScroll.scroll("1. Approach the table\n2. Ignore it and continue.")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        loot = random.randint(1, 100)
        print(loot)
        potionChance = random.randint(1, 2)
        if loot <= 50:
            item1 = random.choice(Items.tierFiveLootPool)
            if potionChance == 1:
                item2 = Items.healthPotion()
            elif potionChance == 2:
                item2 = Items.manaPotion()
            quantity = random.randint(4, 6)
            TextScroll.scroll(f"You found a {item1.name} and a {item2.name} (Quantity: {quantity})!")
            player.inventory.append(item1)
            Items.addToInventory(player, item2, quantity)
        elif loot <= 80:
            potionChance = random.randint(1, 2)
            if potionChance == 1:
                item1 = Items.healthPotion()
            elif potionChance == 2:
                item1 = Items.manaPotion()
            quantity = random.randint(4, 6)
            TextScroll.scroll(f"You found a {item1.name} (Quantity: {quantity})!")
            Items.addToInventory(player, item1, quantity)
        gold = random.randint(150, 300)
        playerMultiplier = player.LUK * 1.1
        gold = round(gold * playerMultiplier)
        player.gold += gold
        TextScroll.scroll(f"You found {gold} gold")
    elif choice == "2":
        TextScroll.scroll("You continue on your journey...")
    endOfRoom(player)
    roomCounter += 1

def treasureRoomSelector(player, roomCounter):
    if player.currentTier == 1:
        tierOneTreasureRoom(player, roomCounter)
    elif player.currentTier == 2:
        tierTwoTreasureRoom(player, roomCounter)
    elif player.currentTier == 3:
        tierThreeTreasureRoom(player, roomCounter)
    elif player.currentTier == 4:
        tierFourTreasureRoom(player, roomCounter)
    elif player.currentTier == 5:
        tierFiveTreasureRoom(player, roomCounter)

##SPECIAL ROOMS##
def restRoom(player):
    TextScroll.scroll("You enter a tranquil room with a fountain in the center.")
    TextScroll.scroll("1. Restore Health and Mana\n2. Level Up")
    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.biChoiceValidate))
    if choice == "1":
        TextScroll.scroll("You feel rejuvenated and refreshed.")
        player.HP = player.maxHP
        player.MP = player.maxMP
    elif choice == "2":
        previousEXP = player.exp
        TextScroll.scroll("You feel a surge of power flow into you...")
        PlayerCharacter.player.levelUp(player)
        player.exp = previousEXP
    input(TextScroll.scroll("Press enter to continue..."))
    endOfRoom(player)

def specialEnemyLoot(player):
    lootList = []
    tempLootPool = []
    if player.currentTier == 1:
        tempLootPool = Items.tierOneLootPool.copy()
    if player.currentTier == 2:
        tempLootPool = Items.tierTwoLootPool.copy()
    if player.currentTier == 3:
        tempLootPool = Items.tierThreeLootPool.copy()
    if player.currentTier == 4:
        tempLootPool = Items.tierFourLootPool.copy()
    if player.currentTier == 5:
        tempLootPool = Items.tierFiveLootPool.copy() 
    for i in range(3):
        listItem = random.choice(tempLootPool)
        lootList.append(listItem)
        tempLootPool.remove(listItem)
    i = 1
    for item in lootList:
        TextScroll.scroll(f"{i}. {lootList[i-1].name}")
        i += 1     

    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.specialLootValidate))
    if choice == "1":
        TextScroll.scroll(f"You have aquired {lootList[0].name}!")
        player.inventory.append(lootList[0])
    elif choice == "2":
        TextScroll.scroll(f"You have aquired {lootList[1].name}!")
        player.inventory.append(lootList[1])
    elif choice == "3":
        TextScroll.scroll(f"You have aquired {lootList[2].name}!")
        player.inventory.append(lootList[2])
    
    endOfRoom(player)

def bossLoot(player):
    lootList = []
    tempLootPool = []
    if player.currentTier == 1:
        tempLootPool = Items.tierOneLootPool.copy()
    if player.currentTier == 2:
        tempLootPool = Items.tierTwoLootPool.copy()
    if player.currentTier == 3:
        tempLootPool = Items.tierThreeLootPool.copy()
    if player.currentTier == 4:
        tempLootPool = Items.tierFourLootPool.copy()
    if player.currentTier == 5:
        tempLootPool = Items.tierFiveLootPool.copy() 
    for i in range(5):
        listItem = random.choice(tempLootPool)
        lootList.append(listItem)
        tempLootPool.remove(listItem)
    i = 1
    for item in lootList:
        TextScroll.scroll(f"{i}. {lootList[i-1].name}")
        i += 1     

    choice = tv.prompt('>', validator = tv.FunctionyValidator(tv.bossLootValidate))
    if choice == "1":
        TextScroll.scroll(f"You have aquired {lootList[0].name}!")
        player.inventory.append(lootList[0])
    elif choice == "2":
        TextScroll.scroll(f"You have aquired {lootList[1].name}!")
        player.inventory.append(lootList[1])
    elif choice == "3":
        TextScroll.scroll(f"You have aquired {lootList[2].name}!")
        player.inventory.append(lootList[2])
    elif choice == "4":
        TextScroll.scroll(f"You have aquired {lootList[3].name}!")
        player.inventory.append(lootList[3])
    elif choice == "5":
        TextScroll.scroll(f"You have aquired {lootList[4].name}!")
        player.inventory.append(lootList[4])

    endOfRoom(player)
        

def gameplayLoop(player, roomCounter):
    roomSelector = 0
    treasureRoomVistited = False
    restRoomVisited = False
    while player.HP > 0 and roomCounter <= 10:
        if roomCounter == 0:
            firstEncounter(player)
            roomCounter += 1
            continue
        elif 1 <= roomCounter < 5:
            roomSelector = random.randint(1, 10)
            if roomSelector <= 2 and treasureRoomVistited == False:
                treasureRoomSelector(player, roomCounter)
                treasureRoomVistited = True
            elif 2 < roomSelector <= 4:
                enemyRoom(player)
            elif 4 < roomSelector <= 6 and restRoomVisited == False:
                restRoom(player)
                restRoomVisited = True
            elif 6 < roomSelector <= 10:
                enemyRoom(player)
            else:
                enemyRoom(player)
            roomCounter += 1
            continue
        elif roomCounter == 5:
            print("AHHH A SPECIAL ENEMY WOW SO COOL.. not implemented yet")
            specialEnemyLoot(player)
            input(TextScroll.scroll("Press enter to continue..."))
            roomCounter += 1
        elif 5 < roomCounter < 10:
            roomSelector = random.randint(1, 10)
            if roomSelector <= 2:
                treasureRoomSelector(player, roomCounter)
                treasureRoomVistited = True
            elif 2 < roomSelector <= 4 and treasureRoomVistited == False:
                enemyRoom(player)
            elif 4 < roomSelector <= 6 and restRoomVisited == False:
                restRoom(player)
                restRoomVisited = True
            elif 6 < roomSelector <= 10:
                enemyRoom(player)
            else:
                enemyRoom(player)
            roomCounter += 1
            continue
        elif roomCounter == 10:
            print("HOLY SHIT A BOSS WOW SO POWERFUL... not implemented yet")
            bossLoot(player)
            roomCounter = 1
            if player.currentTier < 5:
                player.currentTier += 1
                TextScroll.scroll(f"Entering Tier {player.currentTier}")
                treasureRoomVistited = False
                restRoomVisited = False
                continue
            else: 
                TextScroll.scrollSlow("VICTORY")
                break

