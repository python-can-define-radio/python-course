# Cool student examples

- [An expansive extension to the text-based adventure game, by ThanatosBVG](https://github.com/ThanatosBVG/game)
